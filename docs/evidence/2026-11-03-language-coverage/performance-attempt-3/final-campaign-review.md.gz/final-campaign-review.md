# Official final comparison review

## Run and input identity

- Campaign result: exit `1`, elapsed `2513.437986 s`; summary `target/performance-compare-task5-margin-e1c18a1e/comparison.json`.
- Summary SHA-256: `5f22c109c5dd355fbe8daa1a0ce9512ddacdc11e501111840b453a1115e148a5`.
- Summary format version `3`, six workloads, `passed: false`, not diagnostic-only.
- Baseline binary/build metadata hashes: `79eb21fa95d39445e78b7237a0300fe071649d5671db0fbc4b3baff0ee2fd78d` / `d8e35488379f897a6b334343349184398d5f9f52af54386f28522ece5bd2d1c7`.
- Candidate binary/build metadata hashes: `c236e36111785c9ac6bcab6220f07403ad7ad54d02b00590fbe27f6358e40dcc` / `75f60805199dc179ea7fa8f4fc8faedd0fa72a7e90faa40cf7395b5dcdfebbcd`.
- Baseline receipt, manifest, row allowlist hashes: `ae5b1e5ec8500d5b4e7c46b25a6961a9ce56128becfe4e4474f314d90dbf404e`, `fb6e6a8a286acd8900094023d5d8c2b110695eb459c35b52bdfb642fd1a58ec6`, `578ae07fa522f8c0785ef08b86b3215421947ad8f56957c899d8815859cefacb`.
- The summary's build records pin clean baseline source `f9a1b6cfbd6c51e9aecad39a19610695f210ad05` and clean candidate source `e1c18a1eb6b76eb930117235fa19cfce9477e32a`, both `release`, jobs `1`. Host storage is ordinary Btrfs on `/dev/nvme0n1p3`, mounted at `/home`.
- Recomputed hashes of both binaries, both build sidecars, receipt, manifest, row allowlist, and output ledger match the summary pins. No budget approval was loaded.

## Final sample ranges

Each range is `min / median / max` milliseconds across five paired samples. Retry operation counts show the previous attempt and final attempt; the calibration floor kept the same count for the retry.

| Level / workload | Ops previous → final | Baseline previous | Candidate previous | Baseline final | Candidate final | Final result |
|---|---:|---:|---:|---:|---:|---|
| references / fresh_scan | 16 → 16 | 4424 / 4437 / 4738 | 4371 / 4399 / 7269 | 4411 / 4450 / 8868 | 4390 / 4446 / 8880 | Fail: both sample spreads inconclusive after retry |
| references / no_change_scan | 256 | — | — | 5035 / 5136 / 5167 | 4658 / 4716 / 4744 | Pass; no retry |
| references / single_file_update | 256 → 256 | 14714 / 15871 / 19166 | 14208 / 15667 / 16970 | 15306 / 15507 / 24510 | 14164 / 14217 / 14363 | Fail: baseline sample spread inconclusive after retry |
| full / fresh_scan | 16 → 16 | 4652 / 4681 / 5835 | 4640 / 4642 / 4706 | 4672 / 4708 / 4719 | 4632 / 4643 / 4659 | Pass after retry |
| full / no_change_scan | 256 | — | — | 4915 / 5045 / 5115 | 5031 / 5089 / 5351 | Pass; no retry |
| full / single_file_update | 64 → 64 | 4182 / 4251 / 9166 | 3783 / 3823 / 4671 | 4247 / 4290 / 4339 | 3748 / 3828 / 3911 | Pass after retry |

## Calibration rounds

Each entry is `operation_count: baseline_probe_elapsed_ms`; a slash separates the two consecutive probes. The final entry in each sequence was accepted. For retried workloads, the first sequence is the previous attempt and the last is the final attempt.

- references / fresh_scan: first `1:275, 2:556, 4:1098, 8:3044/2493, 16:4449/4426`; retry `16:4429/4468`.
- references / no_change_scan: `1:18, 2:38, 4:72, 8:149, 16:307, 32:656, 64:1295, 128:2600/2593, 256:5039/5003`.
- references / single_file_update: first `1:63, 2:121, 4:262, 8:509, 16:996, 32:2026/1848, 64:4145/3960, 128:8135/16308, 256:15651/15996`; retry `256:15461/15183`.
- full / fresh_scan: first `1:293, 2:593, 4:1170, 8:2351/2359, 16:4682/4675`; retry `16:4675/4679`.
- full / no_change_scan: `1:17, 2:38, 4:77, 8:154, 16:306, 32:620, 64:1244, 128:2409/2437, 256:5032/5053`.
- full / single_file_update: first `1:72, 2:130, 4:251, 8:544, 16:1053, 32:2066/2134, 64:4288/4300`; retry `64:4280/4251`.

The policy in the summary records five paired samples, a 4,000 ms calibration target, two consecutive accepted baseline probes, a 2,000 ms final minimum, spread limits of 10% and 20 ms, and a retry floor equal to the previous calibrated operation count.

## Gate accounting

- Four of six workloads pass. The only final failures are `references/fresh_scan` (`timing: baseline sample spread is inconclusive`; `timing: candidate sample spread is inconclusive`) and `references/single_file_update` (`timing: baseline sample spread is inconclusive`). Both remained inconclusive after the single permitted retry.
- The first `references/fresh_scan` attempt failed candidate spread only. The first `references/single_file_update` attempt failed baseline and candidate spread. `full/fresh_scan` and `full/single_file_update` passed after retries.
- Every `gate_failures` entry is a timing-spread failure. There are zero unallowed row deltas, no approved budget IDs, and no budget, correctness, health, RSS, or artifact-size gate failures.

This campaign remains failed due to host timing noise. Root's next step is to move the final comparison to a quieter Linux host; no additional tuning or same-host retry is indicated.
