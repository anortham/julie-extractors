# Private update timing diagnostic findings

## Scope and result

This was a diagnostic-only run of all languages at references level for single_file_update. The helper copied the v2 comparison implementation from the dirty working tree at source SHA-256 02dae951d74874a85731b539b8e319f5e9eeb281a93d3d360856b90891f96f85, based on repository HEAD bd7369f043dd2c1c4ddd3a76541c1c7ef372cb56. It retained the old two-probe, 2-second calibration and selected 32 operations for its first attempt and 64 on its one retry.

The helper completed in about 210 seconds with exit code 0. It ran five alternating paired samples at each operation count. The summary is marked diagnostic_only=true, gate_result=not_evaluated, and passed=false. The one-workload result remains inconclusive: both final baseline and candidate sample spreads exceeded the timing noise limit. No result here is an official campaign pass.

All 1,378 update operations, including warm-up and calibration, returned status ok and reported 1 changed file plus 43 unchanged files. Of these, 960 are paired-sample operations. The 44-file workload and the semantic validation paths completed. There are 1,462 total run_scan records, including preparation and fresh-equivalence scans.

## Paired samples

Times are totals over the measured operations in each batch. GNU child wall is the sum of per-operation GNU time %e values, each rounded to hundredths of a second. Profile is the sum of report.profile.total_duration_ms. Commit and checkpoint are sums of the corresponding report profile phases.

| Attempt ops | Pair | Order | Side | Parent ms | Child wall ms | Profile ms | Commit ms | WAL checkpoint ms |
|---:|---:|---|---|---:|---:|---:|---:|---:|
| 32 | 0 | baseline then candidate | baseline | 3864 | 3700 | 3717 | 1451 | 1503 |
| 32 | 0 | baseline then candidate | candidate | 1919 | 1780 | 1779 | 467 | 553 |
| 32 | 1 | candidate then baseline | candidate | 1826 | 1700 | 1690 | 409 | 539 |
| 32 | 1 | candidate then baseline | baseline | 2113 | 1990 | 1970 | 685 | 559 |
| 32 | 2 | baseline then candidate | baseline | 2039 | 1920 | 1895 | 672 | 486 |
| 32 | 2 | baseline then candidate | candidate | 1780 | 1640 | 1638 | 401 | 483 |
| 32 | 3 | candidate then baseline | candidate | 3686 | 3500 | 3540 | 1286 | 1546 |
| 32 | 3 | candidate then baseline | baseline | 2260 | 2130 | 2116 | 764 | 626 |
| 32 | 4 | baseline then candidate | baseline | 2030 | 1900 | 1885 | 670 | 483 |
| 32 | 4 | baseline then candidate | candidate | 1765 | 1640 | 1624 | 399 | 481 |
| 64 | 0 | baseline then candidate | baseline | 4170 | 3900 | 3878 | 1379 | 982 |
| 64 | 0 | baseline then candidate | candidate | 3531 | 3260 | 3241 | 804 | 977 |
| 64 | 1 | candidate then baseline | candidate | 3547 | 3240 | 3255 | 812 | 968 |
| 64 | 1 | candidate then baseline | baseline | 6199 | 5940 | 5907 | 2361 | 2129 |
| 64 | 2 | baseline then candidate | baseline | 4110 | 3850 | 3813 | 1373 | 985 |
| 64 | 2 | baseline then candidate | candidate | 3546 | 3240 | 3255 | 808 | 968 |
| 64 | 3 | candidate then baseline | candidate | 4687 | 4390 | 4396 | 1355 | 1563 |
| 64 | 3 | candidate then baseline | baseline | 3604 | 3300 | 3317 | 873 | 971 |
| 64 | 4 | baseline then candidate | baseline | 3682 | 3350 | 3398 | 982 | 971 |
| 64 | 4 | baseline then candidate | candidate | 3518 | 3230 | 3241 | 821 | 967 |

At 64 operations, parent-minus-profile is 277–297 ms per batch, including both steady samples and the tails. The baseline pair 1 outlier is 6.199 s parent, 5.940 s child, and 5.907 s profile. The candidate pair 3 outlier is 4.687 s parent, 4.390 s child, and 4.396 s profile. The parent-minus-profile gap stays about the same as ordinary batches, so parent process supervision and output collection do not account for the large sample spikes. That gap includes unprofiled CLI work and GNU time/process overhead; it is not a pure Command.output measurement.

The first 32-operation attempt had the same shape at lower counts: baseline pair 0 and candidate pair 3 were high. Their writer commit/checkpoint sums were 1.451/1.503 s and 1.286/1.546 s respectively, while the other samples had lower commit/checkpoint totals. The outlier is not tied to one alternating order.

## Writer phase evidence

The CLI maps WritePhaseDurations.commit to artifact_write_commit and WritePhaseDurations.wal_checkpoint to artifact_write_wal_checkpoint in crates/julie-extract-cli/src/commands.rs:1655-1681. The writer closes these intervals immediately after tx.commit() and after finish_journal_after_commit() returns in crates/julie-extract-artifact/src/writer.rs:1280-1283. The latter phase includes the WAL checkpoint; checkpoint_wal executes PRAGMA wal_checkpoint(TRUNCATE) at writer.rs:1510-1512. WritePhaseDurations documents the WAL checkpoint phase and the phase-clock boundaries at model.rs:173-176 and writer.rs:193-214.

The per-scan tails agree with the batch totals. The slowest baseline measured scan in pair 1 was operation 44 in the updated state: parent 227.78 ms, GNU child wall 0.22 s, and profile total 223 ms. Its artifact_write_commit was 133 ms, WAL checkpoint 67 ms, and aggregate artifact_write 208 ms. The slowest candidate scan in pair 3 was operation 56 in the updated state: parent 182.68 ms, GNU child wall 0.18 s, and profile total 178 ms. Its commit was 75 ms, WAL checkpoint 77 ms, and aggregate artifact_write 159 ms.

Across the 64-operation pairs, artifact_write_plan, existing_artifact, and extraction_spool remain near 3–4 ms per operation. Commit and checkpoint phases account for most of the variation. This localizes the tails to the extractor's SQLite write/commit/checkpoint work rather than scan setup or the parent harness.

## Limits

This is strong evidence that the variable time is inside commit/checkpoint work and is consistent with storage synchronization latency. It does not measure individual fsync calls. GNU time %I and %O are filesystem block counts, not syscall durations, and the CLI profiles are wall-clock phase timings. Therefore this run cannot prove which fsync call caused a given tail. A separate predeclared storage diagnostic may test the Btrfs copy-on-write hypothesis; it must compare equal-count sample spreads and retain the same official acceptance limits.

## Retained files

- Raw per-scan records: target/performance-update-timing-diagnostic-20261104/run-all-refs-single-update/run-scan-diagnostic.json
- Diagnostic summary: target/performance-update-timing-diagnostic-20261104/run-all-refs-single-update/comparison.json
- Command output log: target/performance-update-timing-diagnostic-20261104/run-all-refs-single-update.log
- Exit status: target/performance-update-timing-diagnostic-20261104/run-all-refs-single-update.exit
- Pinned command and helper details: target/performance-update-timing-diagnostic-20261104/README.md

The authoritative archive remains under docs/evidence/2026-11-03-language-coverage/update-timing-diagnostics/harness/.
