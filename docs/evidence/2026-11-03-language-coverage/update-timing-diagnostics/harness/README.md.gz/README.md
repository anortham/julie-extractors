# Private update timing diagnostic

This ignored helper copies xtask/src/performance/comparison.rs, compat.rs, and coverage.rs from the task worktree. It filters the harness to the aggregate all/references/single_file_update case and records each run_scan result after its timer stops. The existing preparation, source restore, artifact reset, scan argv, incremental operations, fresh-equivalence validation, baseline receipt checks, exact row comparison, and paired sample order remain in the copied implementation.

The output is always marked diagnostic_only: true and gate_result: not_evaluated; the comparison summary passed field is forced false because this one-workload scope cannot satisfy the six-workload campaign. The CLI prints no pass result. Per-operation records remain in memory until all measurements finish, then write to run-scan-diagnostic.json.

GNU time keeps the existing %M peak RSS field and adds %e child wall seconds, %U user seconds, %S system seconds, %I filesystem input blocks, and %O filesystem output blocks. No strace, side process, or per-operation logging is used. The original scan command remains scan --root ... --db ... --json --level ... --jobs 1.

## Compile only

Run from the task worktree with /bin/bash, login=false, and TMPDIR set to target/coverage-tmp:

~~~
cargo build --offline --manifest-path target/performance-update-timing-diagnostic-20261104/Cargo.toml --target-dir target
~~~

This creates target/debug/performance-instrumented-diagnostic. Compiling does not run the extractor.

## Measurement command

Do not run this until the parent confirms the host is idle. It uses the pinned v1 baseline/candidate binaries and existing manifest, baseline receipt, build metadata, and exact row allowlist. The output directory must be new on every run.

~~~
export TMPDIR=/home/murphy/source/julie-extractors/.worktrees/language-coverage-plan/target/coverage-tmp
export JULIE_PERFORMANCE_DIAGNOSTIC_REPO_ROOT=/home/murphy/source/julie-extractors/.worktrees/language-coverage-plan
target/debug/performance-instrumented-diagnostic \
  --baseline target/coverage-baseline/julie-extract-3.11.0 \
  --candidate target/release/julie-extract \
  --baseline-expectations docs/evidence/2026-11-03-language-coverage/baseline-receipt/baseline-expectations.json \
  --baseline-expectations-sha256 ae5b1e5ec8500d5b4e7c46b25a6961a9ce56128becfe4e4474f314d90dbf404e \
  --baseline-build-metadata docs/evidence/2026-11-03-language-coverage/baseline-build.json \
  --baseline-build-metadata-sha256 d8e35488379f897a6b334343349184398d5f9f52af54386f28522ece5bd2d1c7 \
  --candidate-build-metadata docs/evidence/2026-11-03-language-coverage/candidate-build.json \
  --candidate-build-metadata-sha256 fc4aaa61fbaa9fb29e9c9f44234f1052bd337004b1aa2277950afa264762f73c \
  --manifest fixtures/real-world/coverage-manifest.json \
  --allowlist docs/evidence/2026-11-03-language-coverage/performance-comparison-row-allowlist.json \
  --profile release \
  --out-dir target/performance-update-timing-diagnostic-20261104/run-all-refs-single-update
~~~

Pinned inputs at preparation time:
- Baseline binary SHA-256: 79eb21fa95d39445e78b7237a0300fe071649d5671db0fbc4b3baff0ee2fd78d
- Candidate binary SHA-256: c236e36111785c9ac6bcab6220f07403ad7ad54d02b00590fbe27f6358e40dcc
- Baseline build metadata SHA-256: d8e35488379f897a6b334343349184398d5f9f52af54386f28522ece5bd2d1c7
- Candidate build metadata SHA-256: fc4aaa61fbaa9fb29e9c9f44234f1052bd337004b1aa2277950afa264762f73c
- Baseline receipt SHA-256: ae5b1e5ec8500d5b4e7c46b25a6961a9ce56128becfe4e4474f314d90dbf404e
- Manifest SHA-256: fb6e6a8a286acd8900094023d5d8c2b110695eb459c35b52bdfb642fd1a58ec6
- Exact row allowlist SHA-256: 578ae07fa522f8c0785ef08b86b3215421947ad8f56957c899d8815859cefacb

The official calibrated campaign remains failed/inconclusive. This diagnostic can explain where process time is spent; it cannot change or waive that result.

Base comparison source SHA-256 at copy time: 02dae951d74874a85731b539b8e319f5e9eeb281a93d3d360856b90891f96f85. Repository HEAD at preparation time: bd7369f043dd2c1c4ddd3a76541c1c7ef372cb56.
