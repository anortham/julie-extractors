mod comparison;
mod compat;
mod coverage;

fn main() -> std::process::ExitCode {
    let args = std::env::args().skip(1).collect::<Vec<_>>();
    comparison::run_from_args(&args)
}
