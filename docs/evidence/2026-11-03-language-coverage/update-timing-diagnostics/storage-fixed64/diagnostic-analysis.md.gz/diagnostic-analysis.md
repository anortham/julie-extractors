# Fixed-64 COW versus NOCOW diagnostic

## Run identity

- Source commit: `e2d1869c0ba232a76b26a4ecdef718ab0c9de8ed`
- Baseline binary SHA-256: `79eb21fa95d39445e78b7237a0300fe071649d5671db0fbc4b3baff0ee2fd78d`
- Candidate binary SHA-256: `c236e36111785c9ac6bcab6220f07403ad7ad54d02b00590fbe27f6358e40dcc`
- Candidate build metadata SHA-256: `75f60805199dc179ea7fa8f4fc8faedd0fa72a7e90faa40cf7395b5dcdfebbcd`
- Manifest SHA-256: `fb6e6a8a286acd8900094023d5d8c2b110695eb459c35b52bdfb642fd1a58ec6`
- Storage: `/dev/nvme0n1p3`, Btrfs, mounted at `/home`
- Paired command exit: `0`; runtime reported by the parent: `238.011374 s`
- Output: `paired-cow-vs-nocow/comparison.json` and `paired-cow-vs-nocow/run-scan-diagnostic.json`
- Summary SHA-256: `bb1104bc7e661675dc4f41451f5ca445d162740699fa2626c7b0e9876d47319e`
- Scan records SHA-256: `38372d3e2c277ca866866f04c955e9e6d0ca9597df99c236135921a166e33cf7`

The run used two 64-operation setup batches per arm, excluded from paired statistics, and exactly five alternating baseline/candidate pairs per arm. It produced 1,584 scan records: 1,280 paired measured operations, 256 setup measured operations, and 48 preparation/equivalence scans. All recorded scan statuses were `ok`. No calibration or automatic retry ran.

## Sample spread

Existing spread limit: `max(20 ms, median × 10%)`.

| Storage | Binary | Samples (ms, sorted) | Median | Spread | Limit | Within spread rule |
|---|---|---:|---:|---:|---:|---|
| COW | Baseline | 3986, 4022, 4158, 4296, 5074 | 4158 | 1088 | 415 | No |
| NOCOW | Baseline | 3931, 3957, 3971, 4029, 4526 | 3971 | 595 | 397 | No |
| COW | Candidate | 3531, 3535, 3554, 3560, 3587 | 3554 | 56 | 355 | Yes |
| NOCOW | Candidate | 3335, 3377, 3393, 3408, 3440 | 3393 | 105 | 339 | Yes |

## Writer phase evidence

Times below sum the per-operation extractor profile phases for each 64-operation batch. The largest COW baseline batch was pair 4: parent `5074.5 ms`, profile total `4780 ms`, commit `1747 ms`, WAL checkpoint `1554 ms`, and aggregate artifact write `3785 ms`. The largest NOCOW baseline batch was pair 3: parent `4526.9 ms`, profile total `4241 ms`, commit `1594 ms`, WAL checkpoint `1199 ms`, and aggregate artifact write `3265 ms`.

The individual baseline tails also remained in both arms. COW pair 4 had three scans around `182–190 ms`, with commit plus checkpoint phases around `155–156 ms` each. NOCOW pair 3 had three scans around `164–168 ms`, with commit plus checkpoint phases around `137–141 ms` each. This is consistent with storage-related writer variance in both configurations; the NOCOW sample still contains large spikes. The diagnostic recorded aggregate commit and checkpoint phases, not individual fsync call durations.

The median checkpoint phase was lower with NOCOW: baseline `843 ms` versus COW `969 ms`; candidate `834 ms` versus COW `967 ms`. Baseline commit medians were similar (`1389 ms` NOCOW, `1353 ms` COW). These phase changes do not make the NOCOW baseline samples satisfy the existing spread rule.

## Correctness and attributes

- All ten paired row/health comparisons and both setup comparisons had no failures.
- All six cross-arm semantic-row and health checks, including setup, were equal for both binaries.
- COW source files, artifact directories, databases, and WAL probes had no `C` attribute. NOCOW source files, directories, databases, and WAL probes carried `C` for both binaries.
- The untimed preflight had `measurement_started=false` and zero scan records. SQLite WAL mode was confirmed for both binaries in both arms.

## Decision

The predeclared adoption rule fails: the COW baseline spread exceeded the limit, and the NOCOW baseline spread also exceeded its limit. Do not adopt `+C` for the official comparison. The candidate samples satisfy the spread rule in both arms, but that does not clear the baseline requirement. The six-workload campaign remains a separate gate with unchanged budgets and retry policy.

This was a diagnostic, not a performance acceptance run. No additional storage experiments, retries, or builds were run after it.
