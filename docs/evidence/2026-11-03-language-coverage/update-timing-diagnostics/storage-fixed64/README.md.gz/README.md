# Fixed-64 storage diagnostic

This ignored helper compares ordinary Btrfs copy-on-write storage with a sibling `+C` NOCOW arm. Both arms use the same pinned extractor binaries, corpus, level, workload, scan arguments, correctness checks, and parent/child timing instrumentation. All output stays under a new directory in this task worktree's `target/` tree.

Each arm gets one fixed-64 setup batch per binary outside paired statistics, followed by exactly five alternating baseline/candidate pairs at 64 operations per binary. Pair arm order alternates COW/NOCOW and NOCOW/COW. There is no calibration, retry, tuning, or automatic acceptance. The summary is always diagnostic-only and records per-operation parent elapsed time, GNU time child wall/user/system/I/O fields, report profile phases, row and health checks, and the storage attributes for directories, source files, SQLite databases, and a separate WAL-inheritance probe.

The preflight-only environment switch stages the pinned source inputs and probes directory, database, and WAL attribute inheritance without running an extractor scan. Run it into a new output directory; the paired diagnostic also requires its own new output directory.

## Compile only

Run from the task worktree with `/bin/bash`, `login=false`, and `TMPDIR` set to `target/coverage-tmp`:

~~~
cargo build --offline --manifest-path target/performance-storage-fixed64-diagnostic-20261104/Cargo.toml --target-dir target
~~~

This creates `target/debug/performance-storage-fixed64-diagnostic`. It does not run an extractor.

## Pinned inputs

- Source commit: `e2d1869c0ba232a76b26a4ecdef718ab0c9de8ed`
- Baseline binary SHA-256: `79eb21fa95d39445e78b7237a0300fe071649d5671db0fbc4b3baff0ee2fd78d`
- Candidate binary SHA-256: `c236e36111785c9ac6bcab6220f07403ad7ad54d02b00590fbe27f6358e40dcc`
- Baseline build metadata SHA-256: `d8e35488379f897a6b334343349184398d5f9f52af54386f28522ece5bd2d1c7`
- Candidate build metadata SHA-256: `75f60805199dc179ea7fa8f4fc8faedd0fa72a7e90faa40cf7395b5dcdfebbcd`
- Baseline receipt SHA-256: `ae5b1e5ec8500d5b4e7c46b25a6961a9ce56128becfe4e4474f314d90dbf404e`
- Manifest SHA-256: `fb6e6a8a286acd8900094023d5d8c2b110695eb459c35b52bdfb642fd1a58ec6`
- Exact row allowlist SHA-256: `578ae07fa522f8c0785ef08b86b3215421947ad8f56957c899d8815859cefacb`

## Untimed storage preflight

Run only after the parent confirms the host is idle. This preflight validates the storage setup and WAL attribute inheritance; it does not launch either extractor:

~~~
export TMPDIR=/home/murphy/source/julie-extractors/.worktrees/language-coverage-plan/target/coverage-tmp
export JULIE_PERFORMANCE_DIAGNOSTIC_REPO_ROOT=/home/murphy/source/julie-extractors/.worktrees/language-coverage-plan
JULIE_FIXED64_STORAGE_PREFLIGHT_ONLY=1 target/debug/performance-storage-fixed64-diagnostic \
  --baseline target/coverage-baseline/julie-extract-3.11.0 \
  --candidate target/release/julie-extract \
  --baseline-expectations docs/evidence/2026-11-03-language-coverage/baseline-receipt/baseline-expectations.json \
  --baseline-expectations-sha256 ae5b1e5ec8500d5b4e7c46b25a6961a9ce56128becfe4e4474f314d90dbf404e \
  --baseline-build-metadata docs/evidence/2026-11-03-language-coverage/baseline-build.json \
  --baseline-build-metadata-sha256 d8e35488379f897a6b334343349184398d5f9f52af54386f28522ece5bd2d1c7 \
  --candidate-build-metadata docs/evidence/2026-11-03-language-coverage/candidate-build.json \
  --candidate-build-metadata-sha256 75f60805199dc179ea7fa8f4fc8faedd0fa72a7e90faa40cf7395b5dcdfebbcd \
  --manifest fixtures/real-world/coverage-manifest.json \
  --allowlist docs/evidence/2026-11-03-language-coverage/performance-comparison-row-allowlist.json \
  --profile release \
  --out-dir target/performance-storage-fixed64-diagnostic-20261104/preflight
~~~

## Paired diagnostic

Do not run this until the parent explicitly authorizes the diagnostic and provides a fresh output directory. Use the same pinned arguments as the preflight, remove `JULIE_FIXED64_STORAGE_PREFLIGHT_ONLY`, and change `--out-dir` to a new path such as `target/performance-storage-fixed64-diagnostic-20261104/paired-cow-vs-nocow`.

## Decision rule declared before samples

Use NOCOW for an official comparison only if the COW arm reproduces the sample-spread failure, the NOCOW arm is within the existing `max(20 ms, median × 10%)` spread limit for both binaries at the same 64-operation/five-pair count, commit/checkpoint tails are reduced, and there is no row, health, or cross-arm semantic mismatch. If the COW arm is quiet or the NOCOW arm is noisy, report the storage experiment as inconclusive and do not adopt NOCOW based on medians. Any storage decision remains separate from the six-workload campaign, whose existing budgets and correctness gates still apply unchanged.

No result from this diagnostic is an acceptance pass or a performance budget waiver.
