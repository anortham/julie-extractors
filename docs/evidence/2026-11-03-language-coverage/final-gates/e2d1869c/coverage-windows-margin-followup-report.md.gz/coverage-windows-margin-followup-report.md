# Windows calibration margin follow-up

- Host source is `/home/murphy/source/julie-extractors/.worktrees/language-coverage-plan`, branch `docs/language-coverage-plan`, HEAD `e2d1869c0ba232a76b26a4ecdef718ab0c9de8ed`; final worktree is clean.
- The initial sync attempt for `e1c18a1eb6b76eb930117235fa19cfce9477e32a` was rejected because root-owned evidence edits made that worktree dirty; preserved at `target/coverage-windows-margin-followup-sync.log`.
- Root committed those six evidence files as `e2d1869c0ba232a76b26a4ecdef718ab0c9de8ed`. `git diff e1..e2` confirms only those six evidence paths changed; `crates`, `xtask`, `Cargo.toml`, and `Cargo.lock` are unchanged.
- Successfully synced `e2d1869c0ba232a76b26a4ecdef718ab0c9de8ed` to `C:\work\language-coverage-plan`; sync log: `target/coverage-windows-margin-followup-sync-e2.log`. Guest preflight confirms that exact HEAD, detached clean state, and 5,536,776,192 bytes free on C: (`target/coverage-windows-margin-followup-preflight.log`).
- `cargo test -p xtask` passed on Windows. The xtask library passed 39/39; all package targets passed. Host log: `target/coverage-windows-margin-followup-xtask.log`; win-test log `/home/murphy/.local/share/win-test/logs/20261104T111810Z-language-coverage-plan-3832889.log`.
- No extractor, corpus, or benchmark gate was run. Guest shutdown verified as `shut off` in `target/coverage-windows-margin-followup-guest-status-final.log`.
- No source changes were made during verification.
