import hashlib,json,pathlib,statistics,subprocess
p=pathlib.Path('target/coverage-ci-41856042545')
root=pathlib.Path('docs/evidence/2026-11-03-language-coverage')
load=lambda x:json.loads(x.read_text())
sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
s=load(p/'comparison/comparison.json')
old=load(pathlib.Path('target/performance-compare-task5-margin-e1c18a1e/comparison.json'))
assert s['passed'] and s['format_version']==3 and s['budget_approvals'] is None
assert s['measurement_policy']==old['measurement_policy']
for key in ['manifest_sha256','allowlist_sha256','output_ledger_sha256']:
 assert s[key]==old[key]
a=load(root/'baseline-receipt/baseline-expectations.json')
b=load(p/'rebuilt-baseline-receipt/baseline-expectations.json')
header=lambda x:{k:v for k,v in x.items() if k not in ['baseline_binary_sha256','snapshots']}
assert header(a)==header(b)
key=lambda x:(x['language'],x['level'],x['workload'],x['source_state_sha256'])
assert len(a['snapshots'])==len(b['snapshots'])==10
assert sorted(a['snapshots'],key=key)==sorted(b['snapshots'],key=key)
for label in ['baseline','candidate']:
 meta=load(p/label/'julie-extract.build.json')
 record=load(p/label/'build-record.json')
 assert sha(p/label/'julie-extract')==s[label]['binary_sha256']==meta['binary_sha256']==record['binary_sha256']
 assert sha(p/label/'julie-extract.build.json')==s[label]['build_metadata_sha256']
 assert sha(p/label/'build-record.json')==meta['build']['evidence']['sha256']
 assert sha(p/label/'build.log')==record['build_log_sha256']
 source=s[label]['source']
 assert not source['dirty']
 tree=subprocess.check_output(['git','ls-tree','-rz','--full-tree',source['commit']])
 assert hashlib.sha256(tree).hexdigest()==source['tree_sha256']
 assert meta['build']['profile']=='release' and meta['build']['options']['jobs']=='1'
 assert meta['build']['rustc'].startswith('rustc 1.97.1 ')
 assert len(meta['build']['features'])==267
assert load(p/'baseline/julie-extract.build.json')['build']['features']==load(p/'candidate/julie-extract.build.json')['build']['features']
allow={x['id']:x for x in load(root/'performance-comparison-row-allowlist.json')['entries']}
used=set()
assert len(s['workloads'])==6
assert {(w['level'],w['workload']) for w in s['workloads']}=={(l,w) for l in ['references','full'] for w in ['fresh_scan','no_change_scan','single_file_update']}
rows=[]
for w in s['workloads']:
 assert not w['gate_failures'] and not w['approved_budget_ids']
 n=w['baseline']['calibration_operations']
 assert n==w['candidate']['calibration_operations']
 assert w['previous_attempt'] is None or n>=w['previous_attempt']['baseline']['calibration_operations']
 for label in ['baseline','candidate']:
  arm=w[label]
  assert len(arm['samples'])==5
  assert [x['order'] for x in arm['samples']]==['baseline_then_candidate','candidate_then_baseline','baseline_then_candidate','candidate_then_baseline','baseline_then_candidate']
  assert all(x['normalized']['operation_count']==n for x in arm['samples'])
  for metric in ['elapsed_ms','peak_rss_bytes','artifact_bytes']:
   vals=[x[metric] for x in arm['samples']]
   assert arm[metric]=={'min':min(vals),'median':statistics.median(vals),'max':max(vals)}
  t=arm['elapsed_ms']
  assert t['max']-t['min']<=max(t['median']/10,20)
  if label=='baseline':assert t['min']>=2000
  health=w[label+'_health']
  assert health['files_scanned']==44*n*5
  assert all(health[k]==0 for k in ['files_failed','files_unsupported','errors'])
  assert not health['skipped'] and not health['warnings']
 for metric,rel,absolute in [('elapsed_ms',.10,100),('peak_rss_bytes',.15,33554432),('artifact_bytes',.10,1048576)]:
  for stat in ['median','max']:
   x=w['baseline'][metric][stat]; y=w['candidate'][metric][stat]
   assert not (y-x>absolute and y>x*(1+rel)),(w['level'],w['workload'],metric,stat)
 for d in w['row_deltas']:
  assert d['allowed'] and d['allowlist_id'] in allow
  e=allow[d['allowlist_id']]
  assert all(d[k]==e[k] for k in ['table','action','canonical_row','row_sha256','count','ledger_marker'])
  assert e['level']==w['level']
  used.add(e['id'])
 x=w['baseline']['elapsed_ms']['median']; y=w['candidate']['elapsed_ms']['median']
 rows.append({'level':w['level'],'workload':w['workload'],'operations':n,'baseline_ms':w['baseline']['elapsed_ms'],'candidate_ms':w['candidate']['elapsed_ms'],'median_growth_percent':(y/x-1)*100,'repeated':w['previous_attempt'] is not None})
assert used==set(allow) and len(used)==3090
report={'format_version':1,'passed':True,'workloads_passed':6,'policy_unchanged':True,'frozen_baseline_snapshots_matched':10,'exact_allowance_entries_verified':len(used),'build_features_each':267,'archive_sha256':sha(pathlib.Path('target/coverage-performance-41856042545.zip')),'baseline_binary_sha256':s['baseline']['binary_sha256'],'candidate_binary_sha256':s['candidate']['binary_sha256'],'comparison_sha256':sha(p/'comparison/comparison.json'),'workloads':rows,'independent_reviewer':'/root/parser_correction_review: no acceptance blocker; raw semantic dumps and all provenance also verified'}
pathlib.Path('target/coverage-approved-ci-final-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
