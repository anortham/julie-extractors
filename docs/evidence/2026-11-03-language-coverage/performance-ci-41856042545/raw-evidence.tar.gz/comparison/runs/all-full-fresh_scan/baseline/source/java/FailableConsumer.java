/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.function;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;

/**
 * A functional interface like {@link Consumer} that declares a {@link Throwable}.
 *
 * <p>
 * This is a functional interface whose functional method is {@link #accept(Object)}.
 * </p>
 *
 * @param <T> The type of the argument the consumer accepts.
 * @param <E> The thrown exception type.
 * @since 3.11
 */
@FunctionalInterface
public interface FailableConsumer<T, E extends Throwable> {

    /** NOP singleton */
    @SuppressWarnings("rawtypes")
    FailableConsumer NOP = Function.identity()::apply;

    /**
     * Applies the given {@link FailableConsumer} action to the object if the consumer is not {@code null}. Otherwise, does nothing.
     *
     * @param consumer The consumer to consume.
     * @param object   The object to be consumed.
     * @param <T>      the type of the argument the consumer accepts.
     * @param <E>      The thrown exception type.
     * @throws E Thrown when the consumer fails.
     * @since 3.21.0
     */
    static <T, E extends Throwable> void accept(final FailableConsumer<T, E> consumer, final T object) throws E {
        if (consumer != null) {
            consumer.accept(object);
        }
    }

    /**
     * Gets the NOP singleton.
     *
     * @param <T> The type of the argument the consumer accepts.
     * @param <E> The thrown exception type.
     * @return The NOP singleton.
     */
    @SuppressWarnings("unchecked")
    static <T, E extends Throwable> FailableConsumer<T, E> nop() {
        return NOP;
    }

    /**
     * Accepts the given arguments.
     *
     * @param object The parameter for the consumable to accept
     * @throws E Thrown when the consumer fails.
     */
    void accept(T object) throws E;

    /**
     * Returns a composed {@link Consumer} like {@link Consumer#andThen(Consumer)}.
     *
     * @param after The operation to perform after this operation
     * @return A composed {@link Consumer} like {@link Consumer#andThen(Consumer)}.
     * @throws NullPointerException Thrown when {@code after} is null.
     */
    default FailableConsumer<T, E> andThen(final FailableConsumer<? super T, E> after) {
        Objects.requireNonNull(after, "after");
        return (final T t) -> {
            accept(t);
            after.accept(t);
        };
    }
}
