# Release corpus check

old: code-kb 2.12.0, julie-extract 3.11.0 | new: code-kb 2.12.0, julie-extract 3.12.0

## Result: PASS

## nlohmann-json (bfb0778)

| measure | old | new |
|---|---:|---:|
| scan seconds | 4.0 | 4.0 |
| index MB | 164.0 | 164.0 |
| files | 1232 | 1232 |
| symbols | 38421 | 38421 |
| relationships | 5296 | 5296 |
| pending_relationships | 53518 | 53518 |
| type_facts | 15079 | 15079 |
| identifiers | 147637 | 147637 |
| parse_diagnostics | 8203 | 8203 |
| skipped_files | 0 | 0 |
| upgrade of the old index, seconds | | 4.0 |

Call edges: 5286 (0 gained, 0 lost). Check that each sample is a real call to that target.


Typed receiver calls: 108 (0 gained, 0 lost). Check that each sample is a real call to that target.


Tool calls with changed output: 0.
