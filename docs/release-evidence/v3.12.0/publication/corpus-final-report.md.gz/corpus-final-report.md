# Release corpus check

old: code-kb 2.12.0, julie-extract 3.11.0 | new: code-kb 2.12.0, julie-extract 3.12.0

## Result: PASS

## code-kb (f290fdc)

| measure | old | new |
|---|---:|---:|
| scan seconds | 11.2 | 11.2 |
| index MB | 425.9 | 425.9 |
| files | 1090 | 1090 |
| symbols | 180574 | 180574 |
| relationships | 14013 | 14013 |
| pending_relationships | 63504 | 63504 |
| type_facts | 15670 | 15670 |
| identifiers | 211278 | 211279 |
| parse_diagnostics | 15 | 13 |
| skipped_files | 0 | 0 |
| upgrade of the old index, seconds | | 11.4 |

Call edges: 13932 (0 gained, 0 lost). Check that each sample is a real call to that target.


Typed receiver calls: 781 (0 gained, 0 lost). Check that each sample is a real call to that target.


Tool calls with changed output: 0.

## alamofire (bda9ed5)

| measure | old | new |
|---|---:|---:|
| scan seconds | 7.1 | 6.5 |
| index MB | 412.6 | 412.6 |
| files | 567 | 567 |
| symbols | 112820 | 112820 |
| relationships | 847 | 847 |
| pending_relationships | 72000 | 72000 |
| type_facts | 90271 | 90271 |
| identifiers | 252558 | 252558 |
| parse_diagnostics | 35 | 35 |
| skipped_files | 0 | 0 |
| upgrade of the old index, seconds | | 6.9 |

Call edges: 836 (0 gained, 0 lost). Check that each sample is a real call to that target.


Typed receiver calls: 57 (0 gained, 0 lost). Check that each sample is a real call to that target.


Tool calls with changed output: 0.

## cobra (adbc881)

| measure | old | new |
|---|---:|---:|
| scan seconds | 0.4 | 0.4 |
| index MB | 14.3 | 14.4 |
| files | 66 | 66 |
| symbols | 4218 | 4218 |
| relationships | 600 | 600 |
| pending_relationships | 3033 | 3033 |
| type_facts | 1609 | 1609 |
| identifiers | 18052 | 18052 |
| parse_diagnostics | 0 | 0 |
| skipped_files | 0 | 0 |
| upgrade of the old index, seconds | | 0.5 |

Call edges: 600 (0 gained, 0 lost). Check that each sample is a real call to that target.


Typed receiver calls: 853 (0 gained, 0 lost). Check that each sample is a real call to that target.


Tool calls with changed output: 0.

## express (bed501c)

| measure | old | new |
|---|---:|---:|
| scan seconds | 0.5 | 0.5 |
| index MB | 14.8 | 14.8 |
| files | 213 | 213 |
| symbols | 5610 | 5610 |
| relationships | 349 | 349 |
| pending_relationships | 1513 | 1513 |
| type_facts | 203 | 203 |
| identifiers | 21936 | 21936 |
| parse_diagnostics | 24 | 24 |
| skipped_files | 0 | 0 |
| upgrade of the old index, seconds | | 0.6 |

Call edges: 349 (0 gained, 0 lost). Check that each sample is a real call to that target.


Typed receiver calls: 0 (0 gained, 0 lost). Check that each sample is a real call to that target.


Tool calls with changed output: 0.

## flask (d73fa1c)

| measure | old | new |
|---|---:|---:|
| scan seconds | 0.5 | 0.5 |
| index MB | 16.8 | 16.8 |
| files | 235 | 235 |
| symbols | 6528 | 6528 |
| relationships | 248 | 248 |
| pending_relationships | 3778 | 3778 |
| type_facts | 1337 | 1337 |
| identifiers | 16219 | 16219 |
| parse_diagnostics | 19 | 19 |
| skipped_files | 0 | 0 |
| upgrade of the old index, seconds | | 0.5 |

Call edges: 248 (0 gained, 0 lost). Check that each sample is a real call to that target.


Typed receiver calls: 13 (0 gained, 0 lost). Check that each sample is a real call to that target.


<details><summary>changed: <code>facts</code></summary>

```diff
--- old
+++ new
@@ -1,4 +1,4 @@
-Aliases: sql (4 patterns, 13 facts), route (1 pattern, 306 facts), config (14 patterns, 710 facts), model (3 patterns, 11 facts)
+Aliases: sql (5 patterns, 14 facts), route (1 pattern, 306 facts), config (14 patterns, 710 facts), model (4 patterns, 12 facts)
 
-Available structural fact categories (35 found):
+Available structural fact categories (36 found):
 
@@ -37,2 +37,3 @@
 - `markdown.inline_link.v1` (1 fact)
+- `sql.constraint.v1` (1 fact)
 - `sql.foreign_key.v1` (1 fact)
```
</details>

Tool calls with changed output: 1.

## gson (8b4b550)

| measure | old | new |
|---|---:|---:|
| scan seconds | 1.0 | 1.0 |
| index MB | 73.0 | 73.0 |
| files | 313 | 313 |
| symbols | 16839 | 16839 |
| relationships | 1993 | 1993 |
| pending_relationships | 21948 | 21948 |
| type_facts | 9166 | 9166 |
| identifiers | 63099 | 63099 |
| parse_diagnostics | 0 | 0 |
| skipped_files | 0 | 0 |
| upgrade of the old index, seconds | | 1.0 |

Call edges: 1993 (0 gained, 0 lost). Check that each sample is a real call to that target.


Typed receiver calls: 4085 (0 gained, 0 lost). Check that each sample is a real call to that target.


Tool calls with changed output: 0.

## jq (9d241e2)

| measure | old | new |
|---|---:|---:|
| scan seconds | 0.9 | 0.9 |
| index MB | 42.6 | 42.6 |
| files | 389 | 389 |
| symbols | 16123 | 16123 |
| relationships | 2217 | 2217 |
| pending_relationships | 7455 | 7455 |
| type_facts | 4641 | 4641 |
| identifiers | 35052 | 35052 |
| parse_diagnostics | 500 | 500 |
| skipped_files | 0 | 0 |
| upgrade of the old index, seconds | | 0.9 |

Call edges: 2201 (0 gained, 0 lost). Check that each sample is a real call to that target.


Typed receiver calls: 3 (0 gained, 0 lost). Check that each sample is a real call to that target.


Tool calls with changed output: 0.

## miller (5f244c85)

| measure | old | new |
|---|---:|---:|
| scan seconds | 17.2 | 17.1 |
| index MB | 895.6 | 895.8 |
| files | 2455 | 2455 |
| symbols | 253387 | 253387 |
| relationships | 38312 | 38312 |
| pending_relationships | 175130 | 175128 |
| type_facts | 98697 | 98697 |
| identifiers | 789861 | 789859 |
| parse_diagnostics | 13 | 9 |
| skipped_files | 0 | 0 |
| upgrade of the old index, seconds | | 17.0 |

Call edges: 37554 (0 gained, 0 lost). Check that each sample is a real call to that target.


Typed receiver calls: 7997 (0 gained, 0 lost). Check that each sample is a real call to that target.


Tool calls with changed output: 0.

## moshi (889013e)

| measure | old | new |
|---|---:|---:|
| scan seconds | 0.8 | 0.9 |
| index MB | 44.5 | 44.6 |
| files | 183 | 183 |
| symbols | 9597 | 9597 |
| relationships | 1068 | 1068 |
| pending_relationships | 13653 | 13653 |
| type_facts | 4522 | 4522 |
| identifiers | 39638 | 39638 |
| parse_diagnostics | 4 | 4 |
| skipped_files | 0 | 0 |
| upgrade of the old index, seconds | | 0.9 |

Call edges: 1068 (0 gained, 0 lost). Check that each sample is a real call to that target.


Typed receiver calls: 2743 (0 gained, 0 lost). Check that each sample is a real call to that target.


<details><summary>changed: <code>skeleton moshi-kotlin-tests/codegen-only/src/test/kotlin/com/squareup/moshi/kotlin/codegen/GeneratedAdaptersTest.kt</code></summary>

```diff
--- old
+++ new
@@ -555,26 +555,3 @@
         @Transient val receiver: (String.(String) -> Boolean)? = null; // L1399-1399
-        @Transient val arity: (String.(
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-      ) -> Boolean)? = null { /* 24 lines hidden: L1403-L1426 */ }
+        @Transient val arity: (String.(String, String, String, String, String, String, String, String, String, String, String, String, String, String, String, String, String, String, String, String, String, String) -> Boolean)? = null; // L1401-1427
     } // L1393-1428
```
</details>

Tool calls with changed output: 1.

## newtonsoft-json (09bb545)

| measure | old | new |
|---|---:|---:|
| scan seconds | 4.5 | 4.6 |
| index MB | 176.9 | 176.8 |
| files | 1169 | 1169 |
| symbols | 39969 | 39978 |
| relationships | 3934 | 3934 |
| pending_relationships | 44260 | 44265 |
| type_facts | 24494 | 24494 |
| identifiers | 199975 | 199965 |
| parse_diagnostics | 52 | 14 |
| skipped_files | 0 | 0 |
| upgrade of the old index, seconds | | 6.3 |

Call edges: 3907 (0 gained, 0 lost). Check that each sample is a real call to that target.


Typed receiver calls: 5185 (0 gained, 0 lost). Check that each sample is a real call to that target.


<details><summary>changed: <code>facts</code></summary>

```diff
--- old
+++ new
@@ -9,3 +9,3 @@
 - `yaml.key_value.v1` (92 facts)
-- `powershell.pipeline_expression.v1` (39 facts)
+- `powershell.pipeline_expression.v1` (41 facts)
 - `yaml.mapping.v1` (37 facts)
```
</details>

Tool calls with changed output: 1.

## nlohmann-json (bfb0778)

| measure | old | new |
|---|---:|---:|
| scan seconds | 4.3 | 4.3 |
| index MB | 164.0 | 164.0 |
| files | 1232 | 1232 |
| symbols | 38421 | 38421 |
| relationships | 5296 | 5296 |
| pending_relationships | 53518 | 53518 |
| type_facts | 15079 | 15079 |
| identifiers | 147637 | 147637 |
| parse_diagnostics | 8203 | 8203 |
| skipped_files | 0 | 0 |
| upgrade of the old index, seconds | | 4.4 |

Call edges: 5286 (0 gained, 0 lost). Check that each sample is a real call to that target.


Typed receiver calls: 108 (0 gained, 0 lost). Check that each sample is a real call to that target.


Tool calls with changed output: 0.

## radzen-blazor (50cafbbf)

| measure | old | new |
|---|---:|---:|
| scan seconds | 14.9 | 14.9 |
| index MB | 584.7 | 584.7 |
| files | 3003 | 3003 |
| symbols | 139360 | 139360 |
| relationships | 60098 | 60098 |
| pending_relationships | 82867 | 82867 |
| type_facts | 31862 | 31862 |
| identifiers | 585352 | 585352 |
| parse_diagnostics | 4549 | 4549 |
| skipped_files | 0 | 0 |
| upgrade of the old index, seconds | | 15.1 |

Call edges: 41854 (0 gained, 0 lost). Check that each sample is a real call to that target.


Typed receiver calls: 1418 (0 gained, 0 lost). Check that each sample is a real call to that target.


Tool calls with changed output: 0.

## sinatra (cb22afd)

| measure | old | new |
|---|---:|---:|
| scan seconds | 0.8 | 0.8 |
| index MB | 33.0 | 33.0 |
| files | 292 | 292 |
| symbols | 6731 | 6731 |
| relationships | 1700 | 1700 |
| pending_relationships | 13290 | 13290 |
| type_facts | 306 | 306 |
| identifiers | 25568 | 25568 |
| parse_diagnostics | 0 | 0 |
| skipped_files | 0 | 0 |
| upgrade of the old index, seconds | | 0.8 |

Call edges: 1686 (0 gained, 0 lost). Check that each sample is a real call to that target.


Typed receiver calls: 7 (0 gained, 0 lost). Check that each sample is a real call to that target.


<details><summary>changed: <code>skeleton lib/sinatra/base.rb</code></summary>

```diff
--- old
+++ new
@@ -127,3 +127,3 @@
         /// https://html.spec.whatwg.org/#multipart-form-data
-        MULTIPART_FORM_DATA_REPLACEMENT_TABLE = { /* 5 lines hidden: L407-L411 */ }
+        MULTIPART_FORM_DATA_REPLACEMENT_TABLE = {'"'  => '%22', "\r" => '%0D', "\n" => '%0A'}.freeze; // L407-411
         /// Set the Content-Disposition to "attachment" with the specified filename,
@@ -334,4 +334,3 @@
         def dump_errors!(boom) { /* 14 lines hidden: L1274-L1287 */ }
-        CALLERS_TO_IGNORE = [ # :nodoc:
-        %r { /* 9 lines hidden: L1292-L1300 */ }
+        CALLERS_TO_IGNORE = [# :nodoc: %r{/sinatra(/(base|main|show_exceptions))?\.rb$}, %r{lib/tilt.*\.rb$}, /^\(.*\)$/, /\/bu…; // L1291-1301
         attr_reader :routes; // L1303-1303
@@ -353,4 +352,3 @@
         @extensions = []; // L1318-1318
-        @templates = if superclass.respond_to?(:templates)
-                       Hash.new { /* 3 lines hidden: L1321-L1323 */ }
+        @templates = if superclass.respond_to?(:templates) Hash.new {|_hash, key| superclass.templates[key]} else {} end; // L1320-1324
         /// Extension modules registered on this class and all superclasses.
```
</details>

<details><summary>changed: <code>skeleton test/indifferent_hash_test.rb</code></summary>

```diff
--- old
+++ new
@@ -14,4 +14,3 @@
     def setup() { /* 4 lines hidden: L69-L72 */ }
-    @hash = Sinatra::IndifferentHash[:a=>:a, ?b=>:b, 3=>3,
-      :simple_nested=> { /* 2 lines hidden: L70-L71 */ }
+    @hash = Sinatra::IndifferentHash[:a=>:a, ?b=>:b, 3=>3, :simple_nested=>{:a=>:a, ?b=>:b}, :nested=>{:a=>[{:a=>:a, ?b=>:b…; // L69-72
     def test_hash_constructor() { /* 11 lines hidden: L76-L86 */ }
```
</details>

Tool calls with changed output: 2.

## zod (e516c3b)

| measure | old | new |
|---|---:|---:|
| scan seconds | 2.4 | 2.3 |
| index MB | 106.7 | 106.3 |
| files | 659 | 659 |
| symbols | 42567 | 42567 |
| relationships | 3458 | 3458 |
| pending_relationships | 4950 | 4950 |
| type_facts | 5593 | 5593 |
| identifiers | 122798 | 122798 |
| parse_diagnostics | 30 | 30 |
| skipped_files | 0 | 0 |
| upgrade of the old index, seconds | | 2.3 |

Call edges: 3424 (0 gained, 0 lost). Check that each sample is a real call to that target.


Typed receiver calls: 276 (0 gained, 0 lost). Check that each sample is a real call to that target.


<details><summary>changed: <code>skeleton packages/zod/src/v4/core/schemas.ts</code></summary>

```diff
--- old
+++ new
@@ -34,3 +34,3 @@
 _$ZodType; // L198-199
-$ZodType { /* 123 lines hidden: L201-L323 */ }
+export $ZodType; // L201-323
 runChecks(
@@ -52,3 +52,3 @@
 $ZodString { /* 3 lines hidden: L374-L376 */ }
-$ZodString { /* 21 lines hidden: L378-L398 */ }
+export $ZodString; // L378-398
 $ZodStringFormatDef; // L402-404
@@ -59,3 +59,3 @@
 $ZodStringFormat { /* 1 row hidden: L411-L413 */ }
-$ZodStringFormat { /* 5 lines hidden: L417-L421 */ }
+export $ZodStringFormat; // L415-422
 $ZodGUIDDef; // L425-425
@@ -66,3 +66,3 @@
 $ZodGUID { /* 1 row hidden: L428-L430 */ }
-$ZodGUID { /* 4 lines hidden: L432-L435 */ }
+export $ZodGUID; // L432-435
 $ZodUUIDDef { /* 3 lines hidden: L439-L441 */ }
@@ -73,3 +73,3 @@
 $ZodUUID { /* 1 row hidden: L447-L449 */ }
-$ZodUUID { /* 18 lines hidden: L451-L468 */ }
+export $ZodUUID; // L451-468
 $ZodEmailDef; // L472-472
@@ -80,3 +80,3 @@
 $ZodEmail { /* 1 row hidden: L474-L476 */ }
-$ZodEmail { /* 4 lines hidden: L480-L483 */ }
+export $ZodEmail; // L478-484
 $ZodURLDef { /* 5 lines hidden: L488-L492 */ }
@@ -102,3 +102,3 @@
 urlProtocolOk(url: URL, protocol: RegExp): boolean { /* 4 lines hidden: L536-L539 */ }
-$ZodURL { /* 70 lines hidden: L541-L610 */ }
+export $ZodURL; // L541-610
 $ZodEmojiDef; // L614-614
@@ -109,3 +109,3 @@
 $ZodEmoji { /* 1 row hidden: L617-L619 */ }
-$ZodEmoji { /* 4 lines hidden: L623-L626 */ }
+export $ZodEmoji; // L621-627
 $ZodNanoIDDef; // L631-631
@@ -116,3 +116,3 @@
 $ZodNanoID { /* 1 row hidden: L634-L636 */ }
-$ZodNanoID { /* 4 lines hidden: L640-L643 */ }
+export $ZodNanoID; // L638-644
 $ZodCUIDDef; // L653-653
@@ -135,3 +135,3 @@
 $ZodCUID { /* 1 row hidden: L666-L668 */ }
-$ZodCUID { /* 4 lines hidden: L675-L678 */ }
+export $ZodCUID; // L675-678
 $ZodCUID2Def; // L682-682
@@ -142,3 +142,3 @@
 $ZodCUID2 { /* 1 row hidden: L685-L687 */ }
-$ZodCUID2 { /* 4 lines hidden: L691-L694 */ }
+export $ZodCUID2; // L689-695
 $ZodULIDDef; // L699-699
@@ -149,3 +149,3 @@
 $ZodULID { /* 1 row hidden: L702-L704 */ }
-$ZodULID { /* 4 lines hidden: L706-L709 */ }
```
</details>

<details><summary>changed: <code>skeleton packages/docs/pages/api/_og.tsx</code></summary>

```diff
--- old
+++ new
@@ -2,3 +2,3 @@
 
-config { /* 3 lines hidden: L6-L8 */ }
+export config; // L6-8
 react {
```
</details>

<details><summary>changed: <code>refs $ZodCheckMaxLength -f packages/zod/src/v4/core/checks.ts</code></summary>

```diff
--- old
+++ new
@@ -2,3 +2,3 @@
 Sites: 5 · proven 5 · likely 0 · unresolved 0 · excluded 0
-Text: `$ZodCheckMaxLength` is on 11 lines: 5 sites, 3 definitions, 0 imports, 3 text only.
+Text: `$ZodCheckMaxLength` is on 11 lines: 5 sites, 2 definitions, 0 imports, 4 text only.
 
@@ -10,5 +10,5 @@
 - `SupportedCheck` [packages/zod/src/v4/core/compile.ts:78] (kind: type_usage; import)
-Text only (3): docs, comments, strings, or code the index did not record
+Text only (4): docs, comments, strings, or code the index did not record
   packages/docs/content/packages/core.mdx: 28, 283
-  packages/zod/src/v4/core/checks.ts: 595
+  packages/zod/src/v4/core/checks.ts: 595, 613
 Not visible to this index: calls through computed property names or values built at runtime.
```
</details>

Tool calls with changed output: 3.

## julie-fixtures (22ed5952)

| measure | old | new |
|---|---:|---:|
| scan seconds | 16.3 | 15.8 |
| index MB | 1047.1 | 1050.1 |
| files | 1133 | 1133 |
| symbols | 706852 | 706871 |
| relationships | 2632 | 2644 |
| pending_relationships | 3080 | 3092 |
| type_facts | 3101 | 3109 |
| identifiers | 15133 | 22661 |
| parse_diagnostics | 137 | 44 |
| skipped_files | 0 | 0 |
| upgrade of the old index, seconds | | 16.1 |

Call edges: 2630 (12 gained, 0 lost). Check that each sample is a real call to that target.

- gained: `execute` -> `detach` at real-world/erlang/telemetry-1.3.0/src/telemetry.erl:170 `detach(HandlerId),`
- gained: `DetermineCustomerAccess` -> `T` at extraction/sql/tsql_coverage_regressions/source.sql:43 `FROM dbo.T AS Allowed`
- gained: `span` -> `merge_ctx` at real-world/erlang/telemetry-1.3.0/src/telemetry.erl:339 `merge_ctx(StopMetadata, DefaultCtx)`
- gained: `DetermineCustomerAccess` -> `T` at extraction/sql/tsql_coverage_regressions/source.sql:40 `FROM dbo.T`
- gained: `span` -> `execute` at real-world/erlang/telemetry-1.3.0/src/telemetry.erl:336 `execute(`
- gained: `span` -> `execute` at real-world/erlang/telemetry-1.3.0/src/telemetry.erl:318 `execute(`
- gained: `span` -> `execute` at real-world/erlang/telemetry-1.3.0/src/telemetry.erl:346 `execute(`
- gained: `span` -> `merge_ctx` at real-world/erlang/telemetry-1.3.0/src/telemetry.erl:321 `merge_ctx(StartMetadata, DefaultCtx)`
- gained: `span` -> `merge_ctx` at real-world/erlang/telemetry-1.3.0/src/telemetry.erl:349 `merge_ctx(StartMetadata#{kind => Class, reason => Reason, stacktrace => Stacktrace}, DefaultCtx)`
- gained: `execute` -> `execute` at real-world/erlang/telemetry-1.3.0/src/telemetry.erl:178 `execute([telemetry, handler, failure], FailureMeasurements, FailureMetadata),`

Typed receiver calls: 30 (0 gained, 0 lost). Check that each sample is a real call to that target.


<details><summary>changed: <code>facts</code></summary>

```diff
--- old
+++ new
@@ -1,2 +1,2 @@
-Aliases: sql (23 patterns, 186 facts), route (58 patterns, 328 facts), config (23 patterns, 749866 facts), model (6 patterns, 90 facts), signal (2 patterns, 13 facts), import (4 patterns, 52 facts), binding (2 patterns, 202 facts), component (2 patterns, 140 facts), module (3 patterns, 6 facts), pragma (2 patterns, 3 facts), property (2 patterns, 53 facts)
+Aliases: sql (23 patterns, 207 facts), route (58 patterns, 328 facts), config (23 patterns, 749866 facts), model (6 patterns, 99 facts), signal (2 patterns, 13 facts), import (4 patterns, 52 facts), binding (2 patterns, 202 facts), component (2 patterns, 140 facts), module (3 patterns, 6 facts), pragma (2 patterns, 3 facts), property (2 patterns, 53 facts)
 
@@ -20,3 +20,3 @@
 - `qmldir.object_type.v1` (54 facts)
-- `sql.column_definition.v1` (51 facts)
+- `sql.column_definition.v1` (52 facts)
 - `toml.table.v1` (49 facts)
@@ -35,5 +35,5 @@
 - `java.marker_annotation.v1` (36 facts)
+- `sql.select_query.v1` (36 facts)
 - `blazor.component_reference.v1` (35 facts)
 - `regex.conditional.v1` (33 facts)
-- `sql.select_query.v1` (33 facts)
 - `java.annotation.v1` (32 facts)
@@ -65,2 +65,3 @@
 - `php.anonymous_function.v1` (16 facts)
+- `sql.function_definition.v1` (16 facts)
 - `aspnet.attribute_route.v1` (15 facts)
@@ -69,3 +70,2 @@
 - `scala.annotation.v1` (15 facts)
-- `sql.function_definition.v1` (15 facts)
 - `regex.alternation.v1` (14 facts)
@@ -74,2 +74,3 @@
 - `ruby.require_call.v1` (13 facts)
+- `sql.constraint.v1` (13 facts)
 - `regex.backreference.v1` (12 facts)
@@ -87,2 +88,3 @@
 - `sql.foreign_key.v1` (10 facts)
+- `sql.procedure_definition.v1` (10 facts)
 - `fastify.route.v1` (9 facts)
@@ -93,3 +95,2 @@
 - `rust.benchmark.v1` (9 facts)
-- `sql.procedure_definition.v1` (9 facts)
 - `flask.route.v1` (8 facts)
@@ -100,2 +101,3 @@
 - `regex.character_class.v1` (8 facts)
+- `sql.transaction.v1` (8 facts)
 - `swift_testing.trait.v1` (8 facts)
@@ -158,3 +160,2 @@
 - `spring.functional_route.v1` (5 facts)
-- `sql.constraint.v1` (5 facts)
 - `sql.delete_statement.v1` (5 facts)
@@ -350,3 +351,2 @@
 - `sql.sequence_definition.v1` (1 fact)
-- `sql.transaction.v1` (1 fact)
 - `swiftpm.package.v1` (1 fact)
@@ -368,3 +368,3 @@
 
-- `other` (273447 literals)
+- `other` (273448 literals)
 - `url` (221 literals)
```
</details>

Tool calls with changed output: 1.
