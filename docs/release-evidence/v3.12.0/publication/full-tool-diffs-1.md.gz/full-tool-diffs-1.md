## flask: facts

```diff
--- old
+++ new
@@ -1,5 +1,5 @@
-Aliases: sql (4 patterns, 13 facts), route (1 pattern, 306 facts), config (14 patterns, 710 facts), model (3 patterns, 11 facts)
+Aliases: sql (5 patterns, 14 facts), route (1 pattern, 306 facts), config (14 patterns, 710 facts), model (4 patterns, 12 facts)
 
-Available structural fact categories (35 found):
+Available structural fact categories (36 found):
 
 - `flask.route.v1` (306 facts)
@@ -36,4 +36,5 @@
 - `json.array.v1` (1 fact)
 - `markdown.inline_link.v1` (1 fact)
+- `sql.constraint.v1` (1 fact)
 - `sql.foreign_key.v1` (1 fact)
 - `toml.array_table.v1` (1 fact)
```
