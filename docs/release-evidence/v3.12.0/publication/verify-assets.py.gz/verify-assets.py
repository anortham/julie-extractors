import hashlib,json,pathlib,subprocess,tarfile,zipfile
root=pathlib.Path(__file__).resolve().parent
release=json.loads((root/'release-api.json').read_text())
assert release['tag_name']=='v3.12.0' and not release['draft'] and not release['prerelease']
targets=['aarch64-apple-darwin','x86_64-apple-darwin','aarch64-unknown-linux-gnu','x86_64-unknown-linux-gnu','aarch64-pc-windows-msvc','x86_64-pc-windows-msvc']
expected_names={f'julie-extract-v3.12.0-{t}'+('.zip' if 'windows' in t else '.tar.gz') for t in targets}
assert {a['name'] for a in release['assets']}==expected_names
local=root/'local-package'
documents={p.relative_to(local).as_posix():p.read_bytes() for p in local.rglob('*') if p.is_file() and p.relative_to(local).parts[0]=='docs'}
records=[]
for asset in release['assets']:
 p=root/'assets'/asset['name'];data=p.read_bytes();digest=hashlib.sha256(data).hexdigest()
 assert len(data)==asset['size'] and 'sha256:'+digest==asset['digest']
 target=next(t for t in targets if asset['name'].startswith('julie-extract-v3.12.0-'+t+'.'))
 if p.suffix=='.zip':
  with zipfile.ZipFile(p) as archive:
   assert archive.testzip() is None
   entries={i.filename.removeprefix('./'):archive.read(i) for i in archive.infolist() if not i.is_dir()}
 else:
  with tarfile.open(p) as archive:
   assert all(i.isfile() or i.isdir() for i in archive)
   entries={i.name.removeprefix('./'):archive.extractfile(i).read() for i in archive if i.isfile()}
 assert all(not pathlib.PurePosixPath(n).is_absolute() and '..' not in pathlib.PurePosixPath(n).parts and '\\' not in n for n in entries)
 binary=f'dist/{target}/julie-extract'+('.exe' if 'windows' in target else '')
 assert set(entries)==set(documents)|{binary,binary+'.sha256'}
 assert all(entries[n]==b for n,b in documents.items())
 h=hashlib.sha256(entries[binary]).hexdigest()
 assert entries[binary+'.sha256'].decode()==f'{h}  {binary}\n'
 output=root/'binaries'/target/pathlib.Path(binary).name;output.parent.mkdir(parents=True,exist_ok=True);output.write_bytes(entries[binary]);output.chmod(0o755)
 description=subprocess.check_output(['file','--brief',str(output)],text=True).strip()
 normalized=description.lower()
 assert ('elf 64-bit' in normalized if 'linux' in target else 'mach-o 64-bit' in normalized if 'apple' in target else 'pe32+' in normalized)
 assert ('aarch64' in normalized or 'arm64' in normalized) if target.startswith('aarch64') else ('x86-64' in normalized or 'x86_64' in normalized)
 record={'target':target,'archive':p.name,'bytes':len(data),'sha256':digest,'binary_sha256':h,'file_description':description,'package_members':len(entries),'all_document_bytes_match_pre_tag_package':True}
 if target=='x86_64-unknown-linux-gnu':
  record['executed_version']=subprocess.check_output([str(output),'--version'],text=True).strip()
  assert record['executed_version']=='julie-extract 3.12.0'
 records.append(record)
(root/'asset-verification.json').write_text(json.dumps({'version':'3.12.0','release_url':release['html_url'],'published_at':release['published_at'],'all_six_passed':True,'records':records},indent=2)+'\n')
for r in records:print('PASS',r['target'],r['sha256'])
