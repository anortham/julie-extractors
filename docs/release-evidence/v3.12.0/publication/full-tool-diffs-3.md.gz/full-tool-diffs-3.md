## sinatra: skeleton lib/sinatra/base.rb

```diff
--- old
+++ new
@@ -126,5 +126,5 @@
         def content_type(type = nil, params = { /* 19 lines hidden: L385-L403 */ }
         /// https://html.spec.whatwg.org/#multipart-form-data
-        MULTIPART_FORM_DATA_REPLACEMENT_TABLE = { /* 5 lines hidden: L407-L411 */ }
+        MULTIPART_FORM_DATA_REPLACEMENT_TABLE = {'"'  => '%22', "\r" => '%0D', "\n" => '%0A'}.freeze; // L407-411
         /// Set the Content-Disposition to "attachment" with the specified filename,
         /// instructing the user agents to prompt to save.
@@ -333,6 +333,5 @@
   return false { /* 16 lines hidden: L1255-L1270 */ }
         def dump_errors!(boom) { /* 14 lines hidden: L1274-L1287 */ }
-        CALLERS_TO_IGNORE = [ # :nodoc:
-        %r { /* 9 lines hidden: L1292-L1300 */ }
+        CALLERS_TO_IGNORE = [# :nodoc: %r{/sinatra(/(base|main|show_exceptions))?\.rb$}, %r{lib/tilt.*\.rb$}, /^\(.*\)$/, /\/bu…; // L1291-1301
         attr_reader :routes; // L1303-1303
         attr_reader :filters; // L1303-1303
@@ -352,6 +351,5 @@
         @prototype = nil; // L1317-1317
         @extensions = []; // L1318-1318
-        @templates = if superclass.respond_to?(:templates)
-                       Hash.new { /* 3 lines hidden: L1321-L1323 */ }
+        @templates = if superclass.respond_to?(:templates) Hash.new {|_hash, key| superclass.templates[key]} else {} end; // L1320-1324
         /// Extension modules registered on this class and all superclasses.
         def extensions() { /* 5 lines hidden: L1329-L1333 */ }
```

## sinatra: skeleton test/indifferent_hash_test.rb

```diff
--- old
+++ new
@@ -13,6 +13,5 @@
 class TestIndifferentHash < Minitest::Test {
     def setup() { /* 4 lines hidden: L69-L72 */ }
-    @hash = Sinatra::IndifferentHash[:a=>:a, ?b=>:b, 3=>3,
-      :simple_nested=> { /* 2 lines hidden: L70-L71 */ }
+    @hash = Sinatra::IndifferentHash[:a=>:a, ?b=>:b, 3=>3, :simple_nested=>{:a=>:a, ?b=>:b}, :nested=>{:a=>[{:a=>:a, ?b=>:b…; // L69-72
     def test_hash_constructor() { /* 11 lines hidden: L76-L86 */ }
     def test_assoc() { /* 3 lines hidden: L90-L92 */ }
```

## zod: skeleton packages/zod/src/v4/core/schemas.ts

```diff
--- old
+++ new
@@ -33,5 +33,5 @@
 _$ZodType; // L198-199
 _$ZodType; // L198-199
-$ZodType { /* 123 lines hidden: L201-L323 */ }
+export $ZodType; // L201-323
 runChecks(
       payload: ParsePayload,
@@ -51,5 +51,5 @@
 $ZodString { /* 3 lines hidden: L374-L376 */ }
 $ZodString { /* 3 lines hidden: L374-L376 */ }
-$ZodString { /* 21 lines hidden: L378-L398 */ }
+export $ZodString; // L378-398
 $ZodStringFormatDef; // L402-404
 $ZodStringFormatDef; // L402-404
@@ -58,5 +58,5 @@
 $ZodStringFormat { /* 3 lines hidden: L411-L413 */ }
 $ZodStringFormat { /* 1 row hidden: L411-L413 */ }
-$ZodStringFormat { /* 5 lines hidden: L417-L421 */ }
+export $ZodStringFormat; // L415-422
 $ZodGUIDDef; // L425-425
 $ZodGUIDDef; // L425-425
@@ -65,5 +65,5 @@
 $ZodGUID { /* 3 lines hidden: L428-L430 */ }
 $ZodGUID { /* 1 row hidden: L428-L430 */ }
-$ZodGUID { /* 4 lines hidden: L432-L435 */ }
+export $ZodGUID; // L432-435
 $ZodUUIDDef { /* 3 lines hidden: L439-L441 */ }
 $ZodUUIDDef { /* 1 row hidden: L439-L441 */ }
@@ -72,5 +72,5 @@
 $ZodUUID { /* 3 lines hidden: L447-L449 */ }
 $ZodUUID { /* 1 row hidden: L447-L449 */ }
-$ZodUUID { /* 18 lines hidden: L451-L468 */ }
+export $ZodUUID; // L451-468
 $ZodEmailDef; // L472-472
 $ZodEmailDef; // L472-472
@@ -79,5 +79,5 @@
 $ZodEmail { /* 3 lines hidden: L474-L476 */ }
 $ZodEmail { /* 1 row hidden: L474-L476 */ }
-$ZodEmail { /* 4 lines hidden: L480-L483 */ }
+export $ZodEmail; // L478-484
 $ZodURLDef { /* 5 lines hidden: L488-L492 */ }
 $ZodURLDef { /* 3 rows hidden: L488-L492 */ }
@@ -101,5 +101,5 @@
 urlProtocolOk { /* 4 lines hidden: L536-L539 */ }
 urlProtocolOk(url: URL, protocol: RegExp): boolean { /* 4 lines hidden: L536-L539 */ }
-$ZodURL { /* 70 lines hidden: L541-L610 */ }
+export $ZodURL; // L541-610
 $ZodEmojiDef; // L614-614
 $ZodEmojiDef; // L614-614
@@ -108,5 +108,5 @@
 $ZodEmoji { /* 3 lines hidden: L617-L619 */ }
 $ZodEmoji { /* 1 row hidden: L617-L619 */ }
-$ZodEmoji { /* 4 lines hidden: L623-L626 */ }
+export $ZodEmoji; // L621-627
 $ZodNanoIDDef; // L631-631
 $ZodNanoIDDef; // L631-631
@@ -115,5 +115,5 @@
 $ZodNanoID { /* 3 lines hidden: L634-L636 */ }
 $ZodNanoID { /* 1 row hidden: L634-L636 */ }
-$ZodNanoID { /* 4 lines hidden: L640-L643 */ }
+export $ZodNanoID; // L638-644
 $ZodCUIDDef; // L653-653
 /// @deprecated CUID v1 is deprecated by its authors due to information leakage
@@ -134,5 +134,5 @@
 /// ... (1 more lines)
 $ZodCUID { /* 1 row hidden: L666-L668 */ }
-$ZodCUID { /* 4 lines hidden: L675-L678 */ }
+export $ZodCUID; // L675-678
 $ZodCUID2Def; // L682-682
 $ZodCUID2Def; // L682-682
@@ -141,5 +141,5 @@
 $ZodCUID2 { /* 3 lines hidden: L685-L687 */ }
 $ZodCUID2 { /* 1 row hidden: L685-L687 */ }
-$ZodCUID2 { /* 4 lines hidden: L691-L694 */ }
+export $ZodCUID2; // L689-695
 $ZodULIDDef; // L699-699
 $ZodULIDDef; // L699-699
@@ -148,5 +148,5 @@
 $ZodULID { /* 3 lines hidden: L702-L704 */ }
 $ZodULID { /* 1 row hidden: L702-L704 */ }
-$ZodULID { /* 4 lines hidden: L706-L709 */ }
+export $ZodULID; // L706-709
 $ZodXIDDef; // L713-713
 $ZodXIDDef; // L713-713
@@ -155,5 +155,5 @@
 $ZodXID { /* 3 lines hidden: L716-L718 */ }
 $ZodXID { /* 1 row hidden: L716-L718 */ }
-$ZodXID { /* 4 lines hidden: L720-L723 */ }
+export $ZodXID; // L720-723
 $ZodKSUIDDef; // L727-727
 $ZodKSUIDDef; // L727-727
@@ -162,5 +162,5 @@
 $ZodKSUID { /* 3 lines hidden: L730-L732 */ }
 $ZodKSUID { /* 1 row hidden: L730-L732 */ }
-$ZodKSUID { /* 4 lines hidden: L736-L739 */ }
+export $ZodKSUID; // L734-740
 $ZodISODateTimeDef { /* 5 lines hidden: L744-L748 */ }
 $ZodISODateTimeDef { /* 3 rows hidden: L744-L748 */ }
@@ -169,5 +169,5 @@
 $ZodISODateTime { /* 3 lines hidden: L754-L756 */ }
 $ZodISODateTime { /* 1 row hidden: L754-L756 */ }
-$ZodISODateTime { /* 4 lines hidden: L760-L763 */ }
+export $ZodISODateTime; // L758-764
 $ZodISODateDef; // L768-768
 $ZodISODateDef; // L768-768
@@ -176,5 +176,5 @@
 $ZodISODate { /* 3 lines hidden: L771-L773 */ }
 $ZodISODate { /* 1 row hidden: L771-L773 */ }
-$ZodISODate { /* 4 lines hidden: L777-L780 */ }
+export $ZodISODate; // L775-781
 $ZodISOTimeDef { /* 3 lines hidden: L785-L787 */ }
 $ZodISOTimeDef { /* 1 row hidden: L785-L787 */ }
@@ -183,5 +183,5 @@
 $ZodISOTime { /* 3 lines hidden: L793-L795 */ }
 $ZodISOTime { /* 1 row hidden: L793-L795 */ }
-$ZodISOTime { /* 4 lines hidden: L799-L802 */ }
+export $ZodISOTime; // L797-803
 $ZodISODurationDef; // L807-807
 $ZodISODurationDef; // L807-807
@@ -190,5 +190,5 @@
 $ZodISODuration { /* 3 lines hidden: L810-L812 */ }
 $ZodISODuration { /* 1 row hidden: L810-L812 */ }
-$ZodISODuration { /* 4 lines hidden: L816-L819 */ }
+export $ZodISODuration; // L814-820
 $ZodIPv4Def { /* 3 lines hidden: L824-L826 */ }
 $ZodIPv4Def { /* 1 row hidden: L824-L826 */ }
@@ -197,5 +197,5 @@
 $ZodIPv4 { /* 3 lines hidden: L832-L834 */ }
 $ZodIPv4 { /* 1 row hidden: L832-L834 */ }
-$ZodIPv4 { /* 6 lines hidden: L836-L841 */ }
+export $ZodIPv4; // L836-841
 $ZodIPv6Def { /* 3 lines hidden: L845-L847 */ }
 $ZodIPv6Def { /* 1 row hidden: L845-L847 */ }
@@ -206,5 +206,5 @@
 isValidIPv6 { /* 10 lines hidden: L860-L869 */ }
 isValidIPv6(value: string): boolean { /* 10 lines hidden: L860-L869 */ }
-$ZodIPv6 { /* 18 lines hidden: L871-L888 */ }
+export $ZodIPv6; // L871-888
 $ZodMACDef { /* 3 lines hidden: L891-L893 */ }
 $ZodMACDef { /* 1 row hidden: L891-L893 */ }
@@ -213,5 +213,5 @@
 $ZodMAC { /* 3 lines hidden: L899-L901 */ }
 $ZodMAC { /* 1 row hidden: L899-L901 */ }
-$ZodMAC { /* 6 lines hidden: L903-L908 */ }
+export $ZodMAC; // L903-908
 $ZodCIDRv4Def { /* 3 lines hidden: L912-L914 */ }
 $ZodCIDRv4Def { /* 1 row hidden: L912-L914 */ }
@@ -220,5 +220,5 @@
 $ZodCIDRv4 { /* 3 lines hidden: L920-L922 */ }
 $ZodCIDRv4 { /* 1 row hidden: L920-L922 */ }
-$ZodCIDRv4 { /* 4 lines hidden: L926-L929 */ }
+export $ZodCIDRv4; // L924-930
 $ZodCIDRv6Def { /* 3 lines hidden: L934-L936 */ }
 $ZodCIDRv6Def { /* 1 row hidden: L934-L936 */ }
@@ -229,5 +229,5 @@
 isValidCIDRv6 { /* 10 lines hidden: L946-L955 */ }
 isValidCIDRv6(value: string): boolean { /* 10 lines hidden: L946-L955 */ }
-$ZodCIDRv6 { /* 16 lines hidden: L959-L974 */ }
+export $ZodCIDRv6; // L957-975
 isValidBase64 { /* 13 lines hidden: L978-L990 */ }
 isValidBase64(data: string): boolean { /* 13 lines hidden: L978-L990 */ }
@@ -238,5 +238,5 @@
 $ZodBase64 { /* 3 lines hidden: L995-L997 */ }
 $ZodBase64 { /* 1 row hidden: L995-L997 */ }
-$ZodBase64 { /* 18 lines hidden: L1001-L1018 */ }
+export $ZodBase64; // L999-1019
 isValidBase64URL { /* 6 lines hidden: L1022-L1027 */ }
 isValidBase64URL(data: string): boolean { /* 6 lines hidden: L1022-L1027 */ }
@@ -247,5 +247,5 @@
 $ZodBase64URL { /* 3 lines hidden: L1032-L1034 */ }
 $ZodBase64URL { /* 1 row hidden: L1032-L1034 */ }
-$ZodBase64URL { /* 18 lines hidden: L1038-L1055 */ }
+export $ZodBase64URL; // L1036-1056
 $ZodE164Def; // L1060-1060
 $ZodE164Def; // L1060-1060
@@ -254,5 +254,5 @@
 $ZodE164 { /* 3 lines hidden: L1063-L1065 */ }
 $ZodE164 { /* 1 row hidden: L1063-L1065 */ }
-$ZodE164 { /* 4 lines hidden: L1067-L1070 */ }
+export $ZodE164; // L1067-1070
 /// Luhn checksum on a digit-only string. Adapted from valibot (MIT).
 isLuhnAlgo(digits: string): boolean { /* 11 lines hidden: L1077-L1087 */ }
@@ -265,5 +265,5 @@
 $ZodCreditCard { /* 3 lines hidden: L1099-L1101 */ }
 $ZodCreditCard { /* 1 row hidden: L1099-L1101 */ }
-$ZodCreditCard { /* 15 lines hidden: L1105-L1119 */ }
+export $ZodCreditCard; // L1103-1120
 isValidJWT { /* 16 lines hidden: L1124-L1139 */ }
 isValidJWT(token: string, algorithm: util.JWTAlgorithm | null = null): boolean { /* 16 lines hidden: L1124-L1139 */ }
@@ -274,5 +274,5 @@
 $ZodJWT { /* 3 lines hidden: L1149-L1151 */ }
 $ZodJWT { /* 1 row hidden: L1149-L1151 */ }
-$ZodJWT { /* 14 lines hidden: L1153-L1166 */ }
+export $ZodJWT; // L1153-1166
 $ZodCustomStringFormatDef { /* 3 lines hidden: L1170-L1172 */ }
 $ZodCustomStringFormatDef { /* 1 row hidden: L1170-L1172 */ }
@@ -281,5 +281,5 @@
 $ZodCustomStringFormat { /* 3 lines hidden: L1179-L1181 */ }
 $ZodCustomStringFormat { /* 1 row hidden: L1179-L1181 */ }
-$ZodCustomStringFormat { /* 14 lines hidden: L1185-L1198 */ }
+export $ZodCustomStringFormat; // L1183-1199
 $ZodNumberDef { /* 5 lines hidden: L1209-L1213 */ }
 $ZodNumberDef { /* 2 rows hidden: L1209-L1213 */ }
@@ -288,5 +288,5 @@
 $ZodNumber { /* 3 lines hidden: L1231-L1233 */ }
 $ZodNumber { /* 1 row hidden: L1231-L1233 */ }
-$ZodNumber { /* 34 lines hidden: L1235-L1268 */ }
+export $ZodNumber; // L1235-1268
 $ZodNumberFormatDef; // L1273-1273
 $ZodNumberFormatDef; // L1273-1273
@@ -295,5 +295,5 @@
 $ZodNumberFormat { /* 3 lines hidden: L1280-L1282 */ }
 $ZodNumberFormat { /* 1 row hidden: L1280-L1282 */ }
-$ZodNumberFormat { /* 4 lines hidden: L1286-L1289 */ }
+export $ZodNumberFormat; // L1284-1290
 $ZodBooleanDef { /* 5 lines hidden: L1300-L1304 */ }
 $ZodBooleanDef { /* 3 rows hidden: L1300-L1304 */ }
@@ -302,5 +302,5 @@
 $ZodBoolean { /* 3 lines hidden: L1312-L1314 */ }
 $ZodBoolean { /* 1 row hidden: L1312-L1314 */ }
-$ZodBoolean { /* 21 lines hidden: L1318-L1338 */ }
+export $ZodBoolean; // L1316-1339
 $ZodBigIntDef { /* 5 lines hidden: L1349-L1353 */ }
 $ZodBigIntDef { /* 2 rows hidden: L1349-L1353 */ }
@@ -309,5 +309,5 @@
 $ZodBigInt { /* 3 lines hidden: L1367-L1369 */ }
 $ZodBigInt { /* 1 row hidden: L1367-L1369 */ }
-$ZodBigInt { /* 21 lines hidden: L1371-L1391 */ }
+export $ZodBigInt; // L1371-1391
 $ZodBigIntFormatDef { /* 3 lines hidden: L1396-L1398 */ }
 $ZodBigIntFormatDef { /* 1 row hidden: L1396-L1398 */ }
@@ -316,5 +316,5 @@
 $ZodBigIntFormat { /* 3 lines hidden: L1404-L1406 */ }
 $ZodBigIntFormat { /* 1 row hidden: L1404-L1406 */ }
-$ZodBigIntFormat { /* 4 lines hidden: L1410-L1413 */ }
+export $ZodBigIntFormat; // L1408-1414
 $ZodSymbolDef { /* 3 lines hidden: L1423-L1425 */ }
 $ZodSymbolDef { /* 1 row hidden: L1423-L1425 */ }
@@ -323,5 +323,5 @@
 $ZodSymbol { /* 3 lines hidden: L1432-L1434 */ }
 $ZodSymbol { /* 1 row hidden: L1432-L1434 */ }
-$ZodSymbol { /* 16 lines hidden: L1436-L1451 */ }
+export $ZodSymbol; // L1436-1451
 $ZodUndefinedDef { /* 3 lines hidden: L1460-L1462 */ }
 $ZodUndefinedDef { /* 1 row hidden: L1460-L1462 */ }
@@ -330,5 +330,5 @@
 $ZodUndefined { /* 3 lines hidden: L1471-L1473 */ }
 $ZodUndefined { /* 1 row hidden: L1471-L1473 */ }
-$ZodUndefined { /* 18 lines hidden: L1477-L1494 */ }
+export $ZodUndefined; // L1475-1495
 $ZodNullDef { /* 3 lines hidden: L1505-L1507 */ }
 $ZodNullDef { /* 1 row hidden: L1505-L1507 */ }
@@ -337,5 +337,5 @@
 $ZodNull { /* 3 lines hidden: L1516-L1518 */ }
 $ZodNull { /* 1 row hidden: L1516-L1518 */ }
-$ZodNull { /* 18 lines hidden: L1520-L1537 */ }
+export $ZodNull; // L1520-1537
 $ZodAnyDef { /* 3 lines hidden: L1547-L1549 */ }
 $ZodAnyDef { /* 1 row hidden: L1547-L1549 */ }
@@ -344,5 +344,5 @@
 $ZodAny { /* 3 lines hidden: L1556-L1558 */ }
 $ZodAny { /* 1 row hidden: L1556-L1558 */ }
-$ZodAny { /* 5 lines hidden: L1560-L1564 */ }
+export $ZodAny; // L1560-1564
 $ZodUnknownDef { /* 3 lines hidden: L1574-L1576 */ }
 $ZodUnknownDef { /* 1 row hidden: L1574-L1576 */ }
@@ -351,5 +351,5 @@
 $ZodUnknown { /* 3 lines hidden: L1583-L1585 */ }
 $ZodUnknown { /* 1 row hidden: L1583-L1585 */ }
-$ZodUnknown { /* 5 lines hidden: L1589-L1593 */ }
+export $ZodUnknown; // L1587-1594
 $ZodNeverDef { /* 3 lines hidden: L1604-L1606 */ }
 $ZodNeverDef { /* 1 row hidden: L1604-L1606 */ }
@@ -358,5 +358,5 @@
 $ZodNever { /* 3 lines hidden: L1613-L1615 */ }
 $ZodNever { /* 1 row hidden: L1613-L1615 */ }
-$ZodNever { /* 13 lines hidden: L1617-L1629 */ }
+export $ZodNever; // L1617-1629
 $ZodVoidDef { /* 3 lines hidden: L1639-L1641 */ }
 $ZodVoidDef { /* 1 row hidden: L1639-L1641 */ }
@@ -365,5 +365,5 @@
 $ZodVoid { /* 3 lines hidden: L1648-L1650 */ }
 $ZodVoid { /* 1 row hidden: L1648-L1650 */ }
-$ZodVoid { /* 16 lines hidden: L1652-L1667 */ }
+export $ZodVoid; // L1652-1667
 $ZodDateDef { /* 4 lines hidden: L1676-L1679 */ }
 $ZodDateDef { /* 2 rows hidden: L1676-L1679 */ }
@@ -372,5 +372,5 @@
 $ZodDate { /* 3 lines hidden: L1691-L1693 */ }
 $ZodDate { /* 1 row hidden: L1691-L1693 */ }
-$ZodDate { /* 26 lines hidden: L1695-L1720 */ }
+export $ZodDate; // L1695-1720
 $ZodArrayDef { /* 4 lines hidden: L1730-L1733 */ }
 $ZodArrayDef { /* 2 rows hidden: L1730-L1733 */ }
@@ -380,5 +380,5 @@
 $ZodArray; // L1743-1743
 handleArrayResult(result: ParsePayload<any>, final: ParsePayload<any[]>, index: number) { /* 6 lines hidden: L1745-L1750 */ }
-$ZodArray { /* 45 lines hidden: L1752-L1796 */ }
+export $ZodArray; // L1752-1796
 OptionalOutSchema; // L1806-1806
 OptionalInSchema; // L1807-1807
@@ -424,7 +424,7 @@
   inst: $ZodObject
 ) { /* 44 lines hidden: L1985-L2028 */ }
-$ZodObject { /* 85 lines hidden: L2033-L2117 */ }
+export $ZodObject; // L2033-2117
 get() { /* 9 lines hidden: L2042-L2050 */ }
-$ZodObjectJIT { /* 142 lines hidden: L2121-L2262 */ }
+export $ZodObjectJIT; // L2119-2263
 generateFastpass(shape: any) { /* 96 lines hidden: L2130-L2225; defines `parseStr`, `prefixStr` */ }
 export $InferUnionOutput; // L2273-2273
@@ -441,5 +441,5 @@
 $ZodUnion { /* 1 row hidden: L2296-L2299 */ }
 handleUnionResults(results: ParsePayload[], final: ParsePayload, inst: $ZodUnion, ctx?: ParseContext) { /* 24 lines hidden: L2301-L2324 */ }
-$ZodUnion { /* 62 lines hidden: L2326-L2387 */ }
+export $ZodUnion; // L2326-2387
 handleExclusiveUnionResults(
   results: ParsePayload[],
@@ -452,5 +452,5 @@
 $ZodXor { /* 3 lines hidden: L2431-L2433 */ }
 $ZodXor { /* 1 row hidden: L2430-L2433 */ }
-$ZodXor { /* 35 lines hidden: L2435-L2469 */ }
+export $ZodXor; // L2435-2469
 $ZodDiscriminatedUnionDef { /* 4 lines hidden: L2482-L2485 */ }
 $ZodDiscriminatedUnionDef { /* 2 rows hidden: L2479-L2485 */ }
@@ -468,5 +468,5 @@
 $ZodDiscriminatedUnion { /* 3 lines hidden: L2541-L2543 */ }
 $ZodDiscriminatedUnion { /* 1 row hidden: L2538-L2543 */ }
-$ZodDiscriminatedUnion { /* 89 lines hidden: L2547-L2635 */ }
+export $ZodDiscriminatedUnion; // L2545-2635
 $ZodIntersectionDef { /* 5 lines hidden: L2646-L2650 */ }
 $ZodIntersectionDef { /* 3 rows hidden: L2645-L2650 */ }
@@ -475,5 +475,5 @@
 $ZodIntersection { /* 3 lines hidden: L2663-L2665 */ }
 $ZodIntersection { /* 1 row hidden: L2663-L2665 */ }
-$ZodIntersection { /* 18 lines hidden: L2669-L2686 */ }
+export $ZodIntersection; // L2667-2687
 mergeValues { /* 56 lines hidden: L2692-L2747 */ }
 mergeValues(
@@ -496,5 +496,5 @@
 $ZodTuple { /* 3 lines hidden: L2866-L2868 */ }
 $ZodTuple { /* 1 row hidden: L2863-L2868 */ }
-$ZodTuple { /* 82 lines hidden: L2870-L2951 */ }
+export $ZodTuple; // L2870-2951
 getTupleOptStart(items: readonly $ZodType[], key: "optin" | "optout") { /* 8 lines hidden: L2953-L2960 */ }
 handleTupleResult(result: ParsePayload, final: ParsePayload<any[]>, index: number) { /* 6 lines hidden: L2962-L2967 */ }
@@ -520,5 +520,5 @@
 $ZodRecord { /* 3 lines hidden: L3079-L3081 */ }
 $ZodRecord { /* 1 row hidden: L3078-L3081 */ }
-$ZodRecord { /* 176 lines hidden: L3083-L3258 */ }
+export $ZodRecord; // L3083-3258
 $ZodMapDef { /* 5 lines hidden: L3267-L3271 */ }
 $ZodMapDef { /* 3 rows hidden: L3267-L3271 */ }
@@ -527,5 +527,5 @@
 $ZodMap { /* 3 lines hidden: L3281-L3283 */ }
 $ZodMap { /* 1 row hidden: L3281-L3283 */ }
-$ZodMap { /* 39 lines hidden: L3285-L3323 */ }
+export $ZodMap; // L3285-3323
 handleMapResult(
   keyResult: ParsePayload,
@@ -543,5 +543,5 @@
 $ZodSet { /* 3 lines hidden: L3386-L3388 */ }
 $ZodSet { /* 1 row hidden: L3386-L3388 */ }
-$ZodSet { /* 29 lines hidden: L3390-L3418 */ }
+export $ZodSet; // L3390-3418
 handleSetResult(result: ParsePayload, final: ParsePayload<Set<any>>) { /* 6 lines hidden: L3420-L3425 */ }
 $InferEnumOutput; // L3434-3434
@@ -555,5 +555,5 @@
 $ZodEnum { /* 3 lines hidden: L3456-L3458 */ }
 $ZodEnum { /* 1 row hidden: L3456-L3458 */ }
-$ZodEnum { /* 29 lines hidden: L3460-L3488 */ }
+export $ZodEnum; // L3460-3488
 $ZodLiteralDef { /* 4 lines hidden: L3498-L3501 */ }
 $ZodLiteralDef { /* 2 rows hidden: L3498-L3501 */ }
@@ -562,5 +562,5 @@
 $ZodLiteral { /* 3 lines hidden: L3510-L3512 */ }
 $ZodLiteral { /* 1 row hidden: L3510-L3512 */ }
-$ZodLiteral { /* 30 lines hidden: L3516-L3545 */ }
+export $ZodLiteral; // L3514-3546
 _File; // L3598-3598
 File { /* 4 lines hidden: L3600-L3603 */ }
@@ -573,5 +573,5 @@
 $ZodFile { /* 3 lines hidden: L3619-L3621 */ }
 $ZodFile { /* 1 row hidden: L3619-L3621 */ }
-$ZodFile { /* 17 lines hidden: L3623-L3639 */ }
+export $ZodFile; // L3623-3639
 $ZodTransformDef { /* 4 lines hidden: L3648-L3651 */ }
 $ZodTransformDef { /* 2 rows hidden: L3648-L3651 */ }
@@ -580,5 +580,5 @@
 $ZodTransform { /* 3 lines hidden: L3657-L3659 */ }
 $ZodTransform { /* 1 row hidden: L3657-L3659 */ }
-$ZodTransform { /* 25 lines hidden: L3663-L3687 */ }
+export $ZodTransform; // L3661-3688
 $ZodOptionalDef { /* 4 lines hidden: L3697-L3700 */ }
 $ZodOptionalDef { /* 2 rows hidden: L3697-L3700 */ }
@@ -588,5 +588,5 @@
 $ZodOptional { /* 1 row hidden: L3712-L3714 */ }
 handleOptionalResult(result: ParsePayload) { /* 9 lines hidden: L3716-L3724 */ }
-$ZodOptional { /* 28 lines hidden: L3728-L3755 */ }
+export $ZodOptional; // L3726-3756
 $ZodExactOptionalDef; // L3767-3767
 $ZodExactOptionalDef; // L3767-3767
@@ -595,5 +595,5 @@
 $ZodExactOptional { /* 3 lines hidden: L3776-L3778 */ }
 $ZodExactOptional { /* 1 row hidden: L3776-L3778 */ }
-$ZodExactOptional { /* 13 lines hidden: L3782-L3794 */ }
+export $ZodExactOptional; // L3780-3795
 $ZodNullableDef { /* 4 lines hidden: L3804-L3807 */ }
 $ZodNullableDef { /* 2 rows hidden: L3804-L3807 */ }
@@ -602,5 +602,5 @@
 $ZodNullable { /* 3 lines hidden: L3819-L3821 */ }
 $ZodNullable { /* 1 row hidden: L3819-L3821 */ }
-$ZodNullable { /* 20 lines hidden: L3825-L3844 */ }
+export $ZodNullable; // L3823-3845
 $ZodDefaultDef { /* 6 lines hidden: L3855-L3860 */ }
 $ZodDefaultDef { /* 3 rows hidden: L3855-L3860 */ }
@@ -609,5 +609,5 @@
 $ZodDefault { /* 3 lines hidden: L3871-L3873 */ }
 $ZodDefault { /* 1 row hidden: L3871-L3873 */ }
-$ZodDefault { /* 28 lines hidden: L3877-L3904 */ }
+export $ZodDefault; // L3875-3905
 handleDefaultResult(payload: ParsePayload, def: $ZodDefaultDef) { /* 6 lines hidden: L3907-L3912 */ }
 $ZodPrefaultDef { /* 6 lines hidden: L3922-L3927 */ }
@@ -617,5 +617,5 @@
 $ZodPrefault { /* 3 lines hidden: L3938-L3940 */ }
 $ZodPrefault { /* 1 row hidden: L3938-L3940 */ }
-$ZodPrefault { /* 18 lines hidden: L3944-L3961 */ }
+export $ZodPrefault; // L3942-3962
 $ZodNonOptionalDef { /* 4 lines hidden: L3971-L3974 */ }
 $ZodNonOptionalDef { /* 2 rows hidden: L3971-L3974 */ }
@@ -624,5 +624,5 @@
 $ZodNonOptional { /* 3 lines hidden: L3985-L3987 */ }
 $ZodNonOptional { /* 1 row hidden: L3985-L3987 */ }
-$ZodNonOptional { /* 16 lines hidden: L3991-L4006 */ }
+export $ZodNonOptional; // L3989-4007
 handleNonOptionalResult(payload: ParsePayload, inst: $ZodNonOptional) { /* 11 lines hidden: L4009-L4019 */ }
 $ZodSuccessDef { /* 4 lines hidden: L4068-L4071 */ }
@@ -632,5 +632,5 @@
 $ZodSuccess { /* 3 lines hidden: L4080-L4082 */ }
 $ZodSuccess { /* 1 row hidden: L4080-L4082 */ }
-$ZodSuccess { /* 19 lines hidden: L4086-L4104 */ }
+export $ZodSuccess; // L4084-4105
 $ZodCatchCtx { /* 6 lines hidden: L4114-L4119 */ }
 $ZodCatchCtx { /* 2 rows hidden: L4114-L4119 */ }
@@ -641,5 +641,5 @@
 $ZodCatch { /* 3 lines hidden: L4135-L4137 */ }
 $ZodCatch { /* 1 row hidden: L4135-L4137 */ }
-$ZodCatch { /* 52 lines hidden: L4139-L4190 */ }
+export $ZodCatch; // L4139-4190
 $ZodNaNDef { /* 3 lines hidden: L4199-L4201 */ }
 $ZodNaNDef { /* 1 row hidden: L4199-L4201 */ }
@@ -648,5 +648,22 @@
 $ZodNaN { /* 3 lines hidden: L4208-L4210 */ }
 $ZodNaN { /* 1 row hidden: L4208-L4210 */ }
-$ZodNaN { /* 16 lines hidden: L4212-L4227 */ }
+export $ZodNaN; // L4212-4227
 $ZodPipeDef { /* 9 lines hidden: L4236-L4244 */ }
-/* 102 more rows: L4236-L4981 */
+$ZodPipeDef { /* 5 rows hidden: L4236-L4244 */ }
+$ZodPipeInternals { /* 8 lines hidden: L4247-L4254 */ }
+$ZodPipeInternals { /* 6 rows hidden: L4246-L4254 */ }
+$ZodPipe { /* 3 lines hidden: L4256-L4258 */ }
+$ZodPipe { /* 1 row hidden: L4256-L4258 */ }
+export $ZodPipe; // L4260-4282
+handlePipeResult(left: ParsePayload, next: $ZodType, ctx: ParseContextInternal) { /* 9 lines hidden: L4284-L4292 */ }
+$ZodCodecDef { /* 4 lines hidden: L4301-L4304 */ }
+$ZodCodecDef { /* 2 rows hidden: L4301-L4304 */ }
+$ZodCodecInternals { /* 8 lines hidden: L4307-L4314 */ }
+$ZodCodecInternals { /* 6 rows hidden: L4306-L4314 */ }
+$ZodCodec { /* 3 lines hidden: L4316-L4318 */ }
+$ZodCodec { /* 1 row hidden: L4316-L4318 */ }
+export $ZodCodec; // L4320-4343
+handleCodecAResult(result: ParsePayload, def: $ZodCodecDef, ctx: ParseContextInternal) { /* 23 lines hidden: L4345-L4367 */ }
+handleCodecTxResult(left: ParsePayload, value: any, nextSchema: SomeType, ctx: ParseContextInternal) { /* 9 lines hidden: L4369-L4377 */ }
+$ZodPreprocessDef { /* 4 lines hidden: L4387-L4390 */ }
+/* 85 more rows: L4386-L4981 */
```

## zod: skeleton packages/docs/pages/api/_og.tsx

```diff
--- old
+++ new
@@ -1,5 +1,5 @@
 // File: packages/docs/pages/api/_og.tsx (Lines 1-125)
 
-config { /* 3 lines hidden: L6-L8 */ }
+export config; // L6-8
 react {
     HTMLAttributes {
```

## zod: refs $ZodCheckMaxLength -f packages/zod/src/v4/core/checks.ts

```diff
--- old
+++ new
@@ -1,5 +1,5 @@
 References to interface `$ZodCheckMaxLength` (packages/zod/src/v4/core/checks.ts:608)
 Sites: 5 · proven 5 · likely 0 · unresolved 0 · excluded 0
-Text: `$ZodCheckMaxLength` is on 11 lines: 5 sites, 3 definitions, 0 imports, 3 text only.
+Text: `$ZodCheckMaxLength` is on 11 lines: 5 sites, 2 definitions, 0 imports, 4 text only.
 
 Proven (5):
@@ -9,6 +9,6 @@
 - `$ZodChecks` [packages/zod/src/v4/core/checks.ts:1285] (kind: type_usage; same file)
 - `SupportedCheck` [packages/zod/src/v4/core/compile.ts:78] (kind: type_usage; import)
-Text only (3): docs, comments, strings, or code the index did not record
+Text only (4): docs, comments, strings, or code the index did not record
   packages/docs/content/packages/core.mdx: 28, 283
-  packages/zod/src/v4/core/checks.ts: 595
+  packages/zod/src/v4/core/checks.ts: 595, 613
 Not visible to this index: calls through computed property names or values built at runtime.
```
