## moshi: skeleton moshi-kotlin-tests/codegen-only/src/test/kotlin/com/squareup/moshi/kotlin/codegen/GeneratedAdaptersTest.kt

```diff
--- old
+++ new
@@ -554,28 +554,5 @@
         @Transient val simple: ((String) -> Boolean)? = null; // L1396-1396
         @Transient val receiver: (String.(String) -> Boolean)? = null; // L1399-1399
-        @Transient val arity: (String.(
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-        String,
-      ) -> Boolean)? = null { /* 24 lines hidden: L1403-L1426 */ }
+        @Transient val arity: (String.(String, String, String, String, String, String, String, String, String, String, String, String, String, String, String, String, String, String, String, String, String, String) -> Boolean)? = null; // L1401-1427
     } // L1393-1428
 
```

## newtonsoft-json: facts

```diff
--- old
+++ new
@@ -8,5 +8,5 @@
 - `xml.msbuild_property.v1` (117 facts)
 - `yaml.key_value.v1` (92 facts)
-- `powershell.pipeline_expression.v1` (39 facts)
+- `powershell.pipeline_expression.v1` (41 facts)
 - `yaml.mapping.v1` (37 facts)
 - `manifest.dependency.v1` (31 facts)
```
