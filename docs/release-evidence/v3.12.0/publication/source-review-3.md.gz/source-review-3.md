# Part 3 source adjudication

Reviewed primary /home/murphy/source/julie-extractors, main, 22ed595281f870c251e8e0bfa9b52caff858b3cb. Intentional dirty entries: docs/release.md, untracked docs/release-evidence/2026-11-04-v3-12-0-release.md and publication/. No source edits/tests/builds/scans. Evidence reads used pinned exported source and small indexed artifact queries.

Status: all ten displayed edge samples and six displayed tool changes checked below. All five Sinatra/Zod tool diffs have now been reviewed untruncated. The fixture facts diff is complete at 55 lines, below the 60-line report cap; all its deltas were individually source-checked before the original fixture indexes were accidentally rescanned. No blanket corpus/performance acceptance is asserted.

## Unchanged projects

nlohmann-json bfb0778: zero changed edge samples or tool outputs to adjudicate. Its 4.3->8.2 second scan measurement remains assigned to independent performance investigation, not waived here.
radzen-blazor 50cafbbf: zero changed edge samples/tool outputs; counts unchanged.
Sinatra cb22afd7902b566b6eaba6c4ea89739494a65d12 and Zod e516c3baf22615e20934116abebfed6c000222c2: no gained/lost edge samples.

## All ten sampled fixture edges

Paths below are relative to exported julie-fixtures/fixtures. Eight Erlang samples are in real-world/erlang/telemetry-1.3.0/src/telemetry.erl. Inspected the surrounding execute/3 and span/3 bodies, local detach/1 at133 and merge_ctx/2 at412–413.

1. execute -> detach at170: real detach(HandlerId) in handler-failure catch; valid regained call.
2. DetermineCustomerAccess -> T at extraction/sql/tsql_coverage_regressions/source.sql:43: FROM dbo.T AS Allowed reads table declared at12. Actual artifact kind is references, relationshipType=table_reference, targetTable=T, isExternal=false. Correct; sampler heading Call edges is imprecise.
3. span -> merge_ctx at339: real merge_ctx(StopMetadata, DefaultCtx) in extra-measurements success branch; valid.
4. DetermineCustomerAccess -> T at source.sql:40: outer FROM dbo.T, same declared table; actual kind references with table_reference metadata. Correct, not a function call.
5. span -> execute at336: real execute/3 in extra-measurements success branch; valid.
6. span -> execute at318: real execute/3 initial start event; valid.
7. span -> execute at346: real execute/3 exception event in macro catch; valid.
8. span -> merge_ctx at321: real merge_ctx(StartMetadata, DefaultCtx) initial event metadata; valid.
9. span -> merge_ctx at349: real merge_ctx(updated StartMetadata, DefaultCtx) exception metadata; valid.
10. execute -> execute at178: real recursive execute/3 reporting handler failure; valid.

These gains match the Erlang catch-macro grammar correction and SQL routine grammar recovery declared in docs/contracts/extraction-output-changes.md:139–155. No false published Calls row was found in these samples. The report contains ten samples from twelve gains, not an exhaustive listing of twelve.

## Six changed tool outputs

### Sinatra skeleton lib/sinatra/base.rb

All three displayed changes are corrected ownership, not lost function bodies: MULTIPART_FORM_DATA_REPLACEMENT_TABLE at407–411 is a hash initializer followed by freeze; CALLERS_TO_IGNORE at1291–1301 is an array of regex literals followed by freeze; @templates at1320–1324 is an ordinary variable initializer containing an if expression and nested Hash.new callback. The old body slicing borrowed nested delimiters. New compact declaration output accurately represents the assignments. Callback/method ownership remains separate. Truncated signature text is explicitly ellipsized.

### Sinatra skeleton test/indifferent_hash_test.rb

@hash at69–72 is a Sinatra::IndifferentHash[...] initializer containing nested hashes/arrays, not its own callable body. New compact assignment is expected; setup retains its own body. Source checked through the closing bracket and method end.

### Zod skeleton packages/zod/src/v4/core/schemas.ts

Every displayed removal is an exported const initialized by core.$constructor(..., callback), not a function declaration owned by that const. Checked declaration starts, callback context and closing delimiters for $ZodType201–323, $ZodString378–398, $ZodStringFormat415–422, $ZodGUID432–435, $ZodUUID451–468, $ZodEmail478–484, $ZodURL541–610, $ZodEmoji621–627, $ZodNanoID638–644, $ZodCUID675–678, $ZodCUID2689–695, $ZodULID706–709. New export declarations and widened declaration ranges are expected under language-coverage-corrections-v1. All further hunks are adjudicated in the full-diff addendum below.

### Zod skeleton packages/docs/pages/api/_og.tsx

config6–8 is export const config = {runtime: edge}; an object initializer, not a callable definition. export config with no invented body is correct.

### Zod refs $ZodCheckMaxLength in packages/zod/src/v4/core/checks.ts

Inspected595–620. Line595 is a comment heading. Real declarations are interface at608 and exported const at612; line613 is the string argument "$ZodCheckMaxLength" to core.$constructor, not a third definition. Reclassifying613 from definition to text-only is correct. Five proven sites remain unchanged. Exact source identity/body-ownership correction explains the changed declaration boundary; no caller loss.

### Fixture facts output: every displayed count delta

Used indexed pattern queries to compare old/new structural rows, then read each changed source line. All are source-backed SQL corrections:

- sql.column_definition51->52: add OrderReference and OrderID at real-world/coverage/sql/InsertCustomerOrders.sql:15–16; remove false PERIOD column at extraction/sql/tsql_coverage_regressions/source.sql:16 (PERIOD FOR SYSTEM_TIME).
- sql.select_query33->36: source.sql:29–32 RETURN SELECT CASE, outer SELECT at39 with FROM/WHERE40–45, nested SELECT42 with FROM/WHERE43–44 are real queries.
- sql.function_definition15->16: DetermineCustomerAccess now ends46 instead of swallowing GetAreaCode through55; GetAreaCode48–55 separately present.
- sql.constraint5->13: eight actual FOREIGN KEY constraints added: extraction/sql/basic/source.sql:9; pg_dump/source.sql:19,23,26; pg_semantics/source.sql:21; tsql_coverage_regressions/source.sql:23; tsql_ddl/source.sql:17; tsql_routines/source.sql:12. Names/table/column metadata match those lines.
- sql.procedure_definition9->10: dbo.p at source.sql:1 newly recognized; InsertCustomerOrders corrected extent2–65, including CATCH and final RETURN, rather than ending56.
- sql.transaction1->8: BEGIN/COMMIT/BEGIN/ROLLBACK at source.sql:5,7,8,9 plus BEGIN/COMMIT/ROLLBACK at InsertCustomerOrders.sql:27,54,58. All are explicit transaction actions, not generic BEGIN blocks.
- other literals273447->273448: indexed per-file comparison identifies precisely PRINT N'Unable to create the customer orders.' at InsertCustomerOrders.sql:59. Real previously missed catch-body literal.
- Alias totals sql186->207 = +1 column +3 selects +1 function +8 constraints +1 procedure +7 transactions. model90->99 = +1 column +8 constraints. Other alias counts unchanged.

Regression pointers: crates/julie-extractors/src/tests/sql/structural_facts.rs:734–845 (routine/body/transaction controls), ddl.rs:278–343 (temporal period and bracketed constraint controls); docs/contracts/extraction-output-changes.md:139–175; fixtures/extraction/validation-matrix.json body ownership and SQL dispositions. Tests were read/referenced, not rerun.

## Full Sinatra/Zod diff addendum

Read every hunk of full-probe-diffs-3.md, SHA-256 1fdd2c023cca9cc93e97d22b7dc181f3dd6843c0cf4116aa7d1314af7adcd071. Used file reads only; no database access, CLI query, scan, build, test or automatic indexing during the concurrent performance run.

Sinatra both full diffs, Zod _og.tsx and Zod refs contain no changes beyond those individually adjudicated above. Their dispositions stand.

The full schemas.ts diff contains 68 added export declaration lines: 66 replace borrowed callback-body renderings and two become visible below the former output truncation boundary. For EACH following declaration I inspected its exported const/type annotation, core.$constructor call with callback argument, and actual closing delimiter at the new end line. All are ordinary call-result assignments. None is a direct function-expression initializer whose body should remain on the const; no removal of a genuine owning callable body was found. Broader source spans in multiline declarations now begin at export const rather than the callback.

| Declaration | Exact source lines | Disposition |
| --- | --- | --- |
| `$ZodType` | 201–323 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodString` | 378–398 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodStringFormat` | 415–422 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodGUID` | 432–435 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodUUID` | 451–468 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodEmail` | 478–484 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodURL` | 541–610 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodEmoji` | 621–627 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodNanoID` | 638–644 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodCUID` | 675–678 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodCUID2` | 689–695 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodULID` | 706–709 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodXID` | 720–723 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodKSUID` | 734–740 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodISODateTime` | 758–764 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodISODate` | 775–781 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodISOTime` | 797–803 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodISODuration` | 814–820 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodIPv4` | 836–841 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodIPv6` | 871–888 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodMAC` | 903–908 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodCIDRv4` | 924–930 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodCIDRv6` | 957–975 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodBase64` | 999–1019 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodBase64URL` | 1036–1056 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodE164` | 1067–1070 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodCreditCard` | 1103–1120 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodJWT` | 1153–1166 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodCustomStringFormat` | 1183–1199 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodNumber` | 1235–1268 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodNumberFormat` | 1284–1290 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodBoolean` | 1316–1339 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodBigInt` | 1371–1391 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodBigIntFormat` | 1408–1414 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodSymbol` | 1436–1451 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodUndefined` | 1475–1495 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodNull` | 1520–1537 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodAny` | 1560–1564 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodUnknown` | 1587–1594 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodNever` | 1617–1629 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodVoid` | 1652–1667 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodDate` | 1695–1720 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodArray` | 1752–1796 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodObject` | 2033–2117 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodObjectJIT` | 2119–2263 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodUnion` | 2326–2387 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodXor` | 2435–2469 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodDiscriminatedUnion` | 2545–2635 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodIntersection` | 2667–2687 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodTuple` | 2870–2951 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodRecord` | 3083–3258 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodMap` | 3285–3323 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodSet` | 3390–3418 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodEnum` | 3460–3488 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodLiteral` | 3514–3546 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodFile` | 3623–3639 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodTransform` | 3661–3688 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodOptional` | 3726–3756 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodExactOptional` | 3780–3795 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodNullable` | 3823–3845 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodDefault` | 3875–3905 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodPrefault` | 3942–3962 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodNonOptional` | 3989–4007 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodSuccess` | 4084–4105 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodCatch` | 4139–4190 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodNaN` | 4212–4227 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodPipe` | 4260–4282 | Correct exported call-result declaration; callback body belongs to its callback. |
| `$ZodCodec` | 4320–4343 | Correct exported call-result declaration; callback body belongs to its callback. |

### Newly exposed tail rows

The smaller rendering makes 17 additional rows fit: former footer102 more becomes85 more. These are not evidence of new extraction counts (Zod symbol count remains42567). Read source4236–4390 in full and checked every newly displayed row:

- $ZodPipeDef4236–4244 is an interface with type/in/out/transform/reverseTransform members; its five-member summary is correct.
- $ZodPipeInternals declaration4246–4254 has opening body4247 and six members def/isst/values/optin/optout/propValues; both preexisting interface/export summary styles match.
- $ZodPipe4256–4258 has one _zod member; both displayed summary rows agree.
- $ZodPipe4260–4282 is the ordinary constructor-call assignment listed above.
- handlePipeResult4284–4292 is an actual function with the printed signature and nine-line definition.
- $ZodCodecDef4301–4304 has transform and reverseTransform; both displayed summaries agree.
- $ZodCodecInternals declaration4306–4314 opens its body4307 and contains the same six named members; both summaries agree.
- $ZodCodec4316–4318 is the interface with one _zod member; both summaries agree.
- $ZodCodec4320–4343 is the ordinary constructor-call assignment listed above.
- handleCodecAResult4345–4367 is an actual function with the printed three-argument signature and23-line definition.
- handleCodecTxResult4369–4377 is an actual function with the printed four-argument signature and9-line definition.
- $ZodPreprocessDef declaration4386–4390 opens its interface body4387; displayed body4387–4390 and subsequent footer starting4386 refer to its separate interface/export rows, consistent with the already existing paired representation. No invented source definition.

Conclusion for the untruncated Sinatra/Zod changes: expected declaration-body ownership corrections and resulting output-budget redistribution; no wrong answer found. No claim is made about unreviewed retained rows outside the diff. The fixture facts diff needs no recapture: its 55 lines are below the 60-line cap. Final corpus/performance outcome remains lead-owned pending evidence.

## Final source-answer review disposition

Independently counted the original fixture facts diff: 55 lines, below the report clipping limit of60. There are no hidden fixture facts hunks; every changed count and its source justification is covered above. All ten sampled edges and all six changed tool outputs in part3 are source-adjudicated. Part3 source-answer review is COMPLETE with no wrong answer found. No new fixture CLI capture or database read was performed. Final wide-run nonperformance content must match the reviewed original report; its performance gate remains pending and is not waived by this review.
