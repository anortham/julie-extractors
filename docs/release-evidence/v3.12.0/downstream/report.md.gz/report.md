# Release dogfood report

Commit: 8e2f259733ffc6e30a854c381ea09959a60c6000
Source commit: 8e2f259733ffc6e30a854c381ea09959a60c6000
New: code-kb 2.12.0, julie-extract 3.12.0
Sessions: 20261104T163617Z/claude.md, 20261104T163617Z/codex.md
Claude transcript: 20261104T163617Z/claude.md
Claude transcript SHA-256: 66eef784466395b7baa95d2080192ee4df56a91329649adb92731bb3e3f7b2b9
Codex transcript: 20261104T163617Z/codex.md
Codex transcript SHA-256: 8777f1676ca9fa9d9adbeaa50ba2ea9b01cb5c28f4d525536462f8cadf881482
Input fingerprint: sha256:00a36271db90885146c7b67eac1efdae5beaed797d24b580597f8e0b38df170c
Tested binary: /home/murphy/source/code-kb/.worktrees/julie-3.12.0-dogfood/target/release/code-kb
Tested binary SHA-256: eaf963a324d42ec76db66893d7054a6f2874beb5fde4cd0d5220a2b4e7237bdb
Commit identifies source HEAD; it does not prove how the tested binary was built.
Evidence: target/release-dogfood/evidence.json

## Defects and dispositions

Every reported item was checked against source by the lead and a read-only reviewer. No wrong source fact, false proven target, incorrect location, or missing direct breaking site was confirmed. Existing status alone was not used to dismiss a wrong answer.

- [gap] Claude 1: removed-field sites become unresolved and are not individually rendered; the output preserves the unresolved count and makes no safety claim.
- [gap] Claude 2: bounded test selection omits useful direct tests. The output explicitly reports 266 found and 50 kept; pagination covers retained rows.
- [gap] Claude 3: framework-mediated error-handler tests are not reached. Open ends and the full-suite recommendation expose the missing proof.
- [gap] Claude 4: import/test-client mediated CLI test impact is incomplete; the displayed test sites are correct.
- [gap] Claude 5: one test file is split into repetitive groups.
- [not a defect] Claude 6: the open-end list includes the deeper diagnostic exploration; create_app has unresolved indexed callers while create_app2 does not. Similar function shapes do not require identical caller classifications.
- [gap] Claude 7: receiver alias proof is insufficient; the output says unresolved rather than falsely proven.
- [gap] Claude 8: annotation binding proof is conservative; likely labels do not claim certainty.
- [gap] Claude 9: constructions and textual-reference lists repeat information.
- [not a defect] Claude 10: exact-name lookup deliberately includes a test row. queries.rs:831 and disambiguation_test.rs:832 explicitly implement and test this exception. Clarifying the flag's documentation is a presentation gap. Extracted local-class ownership and parent test metadata are correct.
- [gap] Claude 11: correct route matches are followed by noisy symbol fallback. No exact name concerns symbols, not the separately returned route fact.
- [gap] Claude 12: lookup omits endpoint detail and route enumeration is not discoverable there. Direct facts routes --path examples/tutorial already returns all 13 facts, including endpoint:index.
- [gap] Codex A: Python subscript-callable invocation sites are not emitted as named call identifiers. python/identifiers.rs skips this form in both current and 3.11 sources. Eight found counts indexed rows, not all syntactic calls; include_external does not recover unrecorded callbacks. Recorded as explicit extraction debt in open-gaps.json and docs/plans/2026-11-04-python-subscript-callback-sites.md.
- [not a defect] Codex B depth wording: queries.rs:9434-9451 actually extends the diagnostic walk, and formatters.rs:3491-3494 reports depth five only after that deeper probe found no tests. The displayed default impact depth remains two.
- [gap] Codex B indirect reach: framework/test-client invocation boundaries still limit test-impact coverage, with explicit open ends.
- [gap] Codex C: importing-test impact is incomplete; the returned 60/64 rows are source-valid and include grouped file rows.
- [gap] Codex D: concept ranking orders relevant results poorly; returned definitions and locations remain correct.
- [gap] Codex E: route-prefix lookup and text fallback need better discovery/presentation. Explicit route enumeration works.

## Verification

Both sessions exercised all seven tools and their required variants. Source bodies, signatures, import locations, route facts, caller rows and temporary-edit restoration were checked. Codex independently found all seven direct breaking sites with zero false positives or omissions. No model round was repeated and no source fix or acceptance deferral was required. Both harness worktrees were restored and cleaned by the script. The local code-kb branch contains only verification pin changes; the user's main and toolkit-efficiency worktrees remain untouched.

The release policy allows honest incomplete coverage and heuristic misses. The Python callback limitation remains open extraction debt; it is not relabeled as consumer-only behavior or complete support. The original positive named/attribute-call claims are unchanged.

## Result: PASS
