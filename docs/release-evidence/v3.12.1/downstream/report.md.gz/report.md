# Release dogfood report

Commit: 9d99256be88d69c3693c9bc4b5c554ca394818f3
Source commit: 9d99256be88d69c3693c9bc4b5c554ca394818f3
New: code-kb 2.13.2, julie-extract 3.12.1
Sessions: 20261108T033936Z/claude.md, 20261108T033936Z/codex.md
Claude transcript: 20261108T033936Z/claude.md
Claude transcript SHA-256: fed2f9794a1c4a337c9920658176d3d829ecc2e07aea02efb736b79fe6267a93
Codex transcript: 20261108T033936Z/codex.md
Codex transcript SHA-256: 74a3dd5d6fa9dd81122e9ffaa58d36f27aeb5ace56d1f302032a8b15d7d59316
Input fingerprint: sha256:3219efbe9cf13c0cdd21af89c1a44fc4abac104b5b69d0b449ec0480b1985b02
Tested binary: /home/murphy/source/code-kb/.worktrees/julie-3.12.1/target/release/code-kb
Tested binary SHA-256: 2f6f42956c483779f69757290ec679922a36705d7c61e5cb3bc640061ce125c3
Commit identifies source HEAD; it does not prove how the tested binary was built.
Evidence: target/release-dogfood/evidence.json

## Defects

Both sessions ran against Flask at d73fa1c. Two reports were wrong answers; both are fixed, with a
regression test and a rerun of the reported call. The other reports are gaps or correct output.

Claude session:

- [fixed anortham/julie-extractors@bf1875fd] Claude: `find_references(symbol_name="SessionMixin.accessed")` named the class `AppContext` as the caller of the write at `src/flask/ctx.py:402`, which is inside the property `AppContext.session`. julie ranked a `property` below a class when it chose the containing symbol of an identifier, so code inside a Python `@property` (and a Dart getter or setter) belonged to the class. Fixed in julie-extract 3.12.1 (`property-accessor-container-v1`; regression tests `tests::python::identifiers::code_inside_a_property_accessor_belongs_to_the_property` and `tests::dart::identifiers::code_inside_a_getter_belongs_to_the_getter`, golden `python/declarations`). Rerun with the rebuilt extractor: ``- `session` [src/flask/ctx.py:402] (kind: member_access; receiver type; write)``, and `blast_radius(symbol="SessionMixin.accessed")` now steps to `property session [line 396]`.
- [fixed ea7d709] Claude: `check_edit` with the two edits listed `tests/test_basic.py::test_session_accessed` as a `likely` site of the removed `SessionMixin.accessed` but not among the 50 test commands it kept, while deeper tests of the walk stayed. The tests of a type that lost a field came from the type's own callers report, not from the removed member's. Fixed in code-kb (regression test `the_tests_that_read_a_removed_python_attribute_are_tests_to_run` in `crates/code-kb-core/tests/edit_check_fields_test.rs`). Rerun of `code-kb --root <flask> check` with the same edits: `Tests to run: pytest tests/test_helpers.py::TestHelpers::test_get_debug_flag; pytest tests/test_basic.py::test_session_accessed; …`.
- [gap] Claude: `blast_radius(symbol="Flask.handle_user_exception")` lists no test. The walk stops at `Flask.__call__`, which the werkzeug test client calls (known since 2.13.1), and `test_session_using_application_root` reads `app.wsgi_app` as a value (`PrefixPathMiddleware(app.wsgi_app, "/bar")`, `tests/test_basic.py:301`) instead of calling it; the walk follows calls, not reads of a member. The answer names the open ends and says to run the full suite.
- [gap] Claude: `get_symbol_context(Flask.__init__)` lists the 57 tests that call `Flask(...)` and not the tests that take the `app` fixture, and its open ends show `create_app2` but not the fixture. The context's test list is the report's `Tests that call or use it`; `blast_radius(symbol="Flask.__init__")` follows the fixture and lists them (`uses fixture `app``, 343 tests).
- [gap] Claude: the default `check_edit` page ends `… 230 more` and the next line says `the check keeps 50 of 238`; `… N more` counts every other test found, as documented, and with `limit=200` the page still shows the 50 kept. The line `Not checked: calls inside macro arguments, callback invocation contracts.` prints for every language; a Python check could leave the macro clause out.
- [gap] Claude: `blast_radius()` on the whole diff found 333 tests where `check_edit` found 238 for the same edits, and lists `test_session_error_pops_context` (encloses `FailingSessionInterface`) and the impact row `class Flask [line 110]`. The walk starts from the innermost symbol that holds each changed line, and the removed `accessed = False` line seeds the class `SessionMixin`, whose subclasses and constructions the walk then follows; `check_edit` walks only from the sites of the shape change. Documented, different scopes.
- [gap] Claude: `lookup_symbol(query="/auth", kind="route")` finds no route. A route matches by its shape or its tail (`/auth/login` for `/auth/login`), not by a prefix; no query lists every route of an app. Feature request.
- [gap] Claude: `lookup_symbol(query="/auth/login")` lists the two exact routes and then 15 ranked full-text rows (`conf.py author`, `Flask.test_client`, HTML `<a>` elements). The ranked section prints when no name row has the query as its name; a route match could end the answer.
- [not a defect] Claude: `file_skeleton(src/flask/sansio/scaffold.py)` leaves out `self.static_folder` and `self.static_url_path` (lines 87-88). The class defines both names as `@property`, so these rows are writes, not definitions, and skeletons leave them out (CLAUDE.md, invariant 5). The `{ }`, `extends`, `;`, and `///` forms are the one skeleton syntax for every language.

Codex session:

- [not a defect] Codex: `lookup_symbol(query="Flask", kind="class")` lists `class Flask [tests/test_config.py:202-203]`. A lookup row whose name equals the query is shown with or without `is_test`, as documented.
- [gap] Codex: `get_symbol_context` and `blast_radius` on `Flask.handle_user_exception` list no test; the same open end as the Claude gap above.
- [gap] Codex: `get_symbol_context(AuthActions)` and `get_symbol_context(AuthActions.__init__)` list no test, although the `auth` fixture builds `AuthActions` and the tutorial tests take it. The context lists direct callers; `blast_radius(symbol="AuthActions")` lists the 10 tests with `uses fixture `auth``.
- [gap] Codex: `find_references(Flask.wsgi_app, direction="callees")` shows 6 callees by default and 8 with `include_external`; `response(environ, start_response)` at `app.py:1607` is a call on a local variable that names no workspace symbol, so the default filter drops it, and `environ["werkzeug.debug.preserve_context"](ctx)` at line 1610 has no callee row because julie records none for a call on a subscript result (also in the 2.13.2 round).
- [gap] Codex: `lookup_symbol(query="/")` lists only the exact `/` routes and `lookup_symbol(query="/auth")` no route; the same prefix gap as the Claude report above, and the `/auth` ranked rows match `author`.
- [gap] Codex: `find_references(Flask)` prints `Imported 26 times in 24 files` with three locations; the import line is a summary by design, and `lookup_symbol(query="Flask", kind="import")` lists all 26.
- [not a defect] Codex: `blast_radius(file="src/flask/cli.py")` ends with `No supported runner configuration covers 1 reported path: examples/celery/src/task_app/__init__.py; check it by hand.` The line names a reported path (`create_app` at depth 2 is an impacted symbol in that file) that no configured runner covers, so the reader knows the index verifies nothing there; it does not call the file a test.

Every `check_edit` site both sessions checked against the source was a real break (5 of 5 for `get_debug_flag`, 17 of 17 and 2 of 2 in the tutorial edit, and the 5 reads of `SessionMixin.accessed`, of which the two after `ctx.py:402` only raise once the write is gone too), and `check_edit` after the restores said `no symbol changed shape.` No session found a wrong location, a wrong count, or a crash.

The two fixes change the extractor binary, so this round is the downstream evidence of julie-extract 3.12.1; the code-kb release that pins the published 3.12.1 runs its own round against the pinned archive binary.

## Result: PASS
