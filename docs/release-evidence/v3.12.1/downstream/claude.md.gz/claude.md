I answered all six questions and used every code-kb tool at least once. The worktree is clean again: `git status` shows no changes, and the last check_edit reports "no symbol changed shape". I found 9 defects in code-kb.

## Answers

**1. How a WSGI request becomes a response (`src/flask/app.py`)**
- The WSGI server calls `Flask.__call__` (line 1621), which calls `wsgi_app` (line 1569).
- `wsgi_app` makes a context with `request_context(environ)`, pushes it, and calls `full_dispatch_request` (line 995).
- `full_dispatch_request` sends the `request_started` signal, then calls `preprocess_request`, which runs the before-request functions.
- If `preprocess_request` returns nothing, `dispatch_request` (line 969) runs. It raises routing errors, answers automatic OPTIONS requests, or calls the view function.
- `finalize_request` (line 1024) calls `make_response` and `process_response`, which runs the after-request functions and saves the session. Then it sends the `request_finished` signal.
- Last, `wsgi_app` calls `response(environ, start_response)`, and `ctx.pop(error)` runs the teardown functions.

**Where errors are handled:**
- An exception inside the dispatch goes to `handle_user_exception` (line 868).
  - An `HTTPException` goes to `handle_http_exception` (line 833).
  - Other exceptions go to the registered error handler, if one matches.
  - With no handler, the exception is raised again.
- An exception that is still not handled reaches `handle_exception` (line 900), which `wsgi_app` calls. It sends `got_request_exception`.
  - In debug or testing mode, it raises the exception again.
  - In other modes, it logs the error and returns a 500 response through the 500 handler.

**2. Instance attributes set in `__init__`**
- `Flask.__init__` itself sets only `self.cli` (and `self.cli.name`). It also adds the static route.
- `App.__init__` (`sansio/app.py:279`), called through `super()`:
  - `instance_path`, `config`, `aborter`, `json`
  - `url_build_error_handlers`, `teardown_appcontext_funcs`, `shell_context_processors`
  - `blueprints`, `extensions`, `url_map`, `subdomain_matching`, `_got_first_request`
- `Scaffold.__init__` (`sansio/scaffold.py`):
  - `import_name`, `static_folder`, `static_url_path`, `template_folder`, `root_path`, `view_functions`
  - `error_handler_spec`, `before_request_funcs`, `after_request_funcs`, `teardown_request_funcs`
  - `template_context_processors`, `url_value_preprocessors`, `url_default_functions`

**3. Tests to run**
- For `handle_user_exception`, no test calls it directly. The tests reach it through the test client:
  - all tests in `tests/test_user_error_handler.py`
  - the error-handler tests in `tests/test_basic.py`, such as `test_error_handling`, `test_user_error_handling` and `test_trap_bad_request_key_error`
  - the error-handler tests in `tests/test_blueprints.py`, such as `test_blueprint_specific_user_error_handling`
- For `src/flask/cli.py`: `tests/test_cli.py`, plus the CLI-runner tests in `tests/test_testing.py`. blast_radius found 60 tests.

**4. Where `Flask` is imported**
- 26 import statements in 24 files. lookup_symbol with `kind="import"` lists all of them, and grep confirms the list.
  - `src/flask`: `__init__.py:2`, `cli.py:34,45,124`, `ctx.py:21`, `globals.py:9`, `sessions.py:19`, `testing.py:24`
  - Examples: celery, javascript, and `tutorial/flaskr/__init__.py`
  - Tests: `tests/conftest.py`, `test_async.py`, `test_cli.py`, `test_request.py`, 9 app files in `tests/test_apps/`, and 3 files in `tests/type_check/`
- About 20 more test files use `import flask` and then `flask.Flask`.

**5. Routes in the tutorial app (`examples/tutorial/flaskr`)**
- `GET /hello` → `hello`
- `GET /` → endpoint `index` (`add_url_rule`), and `blog.index`
- `GET, POST /auth/register`; `GET, POST /auth/login`; `GET /auth/logout`
- `GET, POST /create`; `GET, POST /<int:id>/update`; `POST /<int:id>/delete`
- Flask also adds the static route automatically.

**6. The check_edit test**
- I added a required parameter to `get_debug_flag` (`src/flask/helpers.py`). check_edit listed 5 call sites. All 5 break, and grep finds no other call site.
- I removed the field `SessionMixin.accessed` (`src/flask/sessions.py`). check_edit listed 5 read sites:
  - `sessions.py:339` breaks: `save_session` reads the field on sessions that nothing has accessed.
  - `test_basic.py:254` and `:275` break.
  - `test_basic.py:261` and `:268` do not break by themselves: `ctx.py:402` sets the attribute before those reads.
- No breaking site is missing. check_edit correctly leaves out the write at `ctx.py:402`, which does not break.

## Defect report

1. **blast_radius(symbol="Flask.handle_user_exception"): wrong.**
   - Output: "No test reaches it within depth 5. Run the full test suite."
   - The tool lists `wsgi_app` at depth 2. find_references shows `test_session_using_application_root` uses `app.wsgi_app` (`tests/test_basic.py:301`), so that test is 3 steps away.
   - Correct output: at least that test. Ideally also the tests that reach the method through the test client (see question 3).

2. **get_symbol_context(Flask.__init__): incomplete test list.**
   - Output: "Tests to run" lists only tests that call `Flask(...)` directly, about 57.
   - It ignores the pytest fixture `app` (`tests/conftest.py:29`), which about 258 tests use. The Open Ends list shows only `create_app2`, not the fixture.
   - Correct output: link each fixture to the tests that request it, or list `app` as an open end.

3. **check_edit (with the two edits): important test missing.**
   - Output: "Tests to run (238 found, 50 kept)".
   - The 50 kept tests do not include `tests/test_basic.py::test_session_accessed`, although check_edit lists that test as a broken site.
   - Correct output: rank the tests that touch a changed site first.

4. **check_edit (default page): misleading count.**
   - Output: "… 230 more", but also "keeps 50 of 238". With `limit=200` it shows only 50 rows.
   - Correct output: "42 more of 50 kept (188 dropped)".
   - The same output also says "Not checked: calls inside macro arguments". Python has no macros, so this line is noise.

5. **blast_radius() on the whole diff: noisy, and the count differs from check_edit.**
   - Output: "Showing 20 of 333 likely tests". check_edit found 238 for the same diff.
   - The list includes tests such as `test_session_error_pops_context` ("encloses `FailingSessionInterface`") and the impact row "class `Flask` [line 110]".
   - The diff changed only `get_debug_flag` and `SessionMixin.accessed`. The tool treats every symbol in each changed file as changed.

6. **lookup_symbol(query="/auth", kind="route"): wrong.**
   - Output: "No symbols found … No similar name is indexed; check the workspace and spelling."
   - Three `/auth/*` routes exist, and the tool finds them by their full paths.
   - `query="/"` returns only the exact `/` routes. No query lists all routes of an app.
   - Correct output: match routes by path prefix.

7. **lookup_symbol(query="/auth/login"): noisy.**
   - It found the two exact route matches, then added 15 full-text rows.
   - Those rows include `docs/conf.py author = "Pallets"`, `Flask.test_client` (because of "self._authentication"), and HTML `<a>` elements with scores near -190.
   - Correct output: stop after the exact route match.

8. **file_skeleton(src/flask/sansio/scaffold.py): incomplete.**
   - The skeleton lists only the attributes that have doc comments.
   - It leaves out `self.static_folder` and `self.static_url_path` (lines 87–88).
   - For Python code, it also uses C-like syntax (`{ }`, `extends`, `;`, `///`), which can mislead the reader.

9. **find_references(symbol_name="SessionMixin.accessed"): wrong enclosing symbol.**
   - Output: "`AppContext` [src/flask/ctx.py:402]".
   - The write is inside the property `AppContext.session` (line 395). Correct output: `AppContext.session`.

10. **No defects (each checked against the source):**
    - find_references with callers (`Flask`: 100 constructions match grep; `wsgi_app`; `get_debug_flag`) and with callees (`full_dispatch_request`).
    - get_symbol_body: line ranges and bodies are correct.
    - lookup_symbol with descriptive words: the blog and auth views ranked first.
    - The folder skeleton of `src/flask`.
    - The check_edit call-site rows, and the clean result after the restore.
